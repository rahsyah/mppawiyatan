/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface LetterData {
  id: string;
  nomorSurat: string;
  namaInstansi: string;
  kopSurat: string; // custom address / detail kop
  logoInstansi: string; // Base64 image
  tanggalSurat: string;
  kepada: string;
  isiSurat: string; // HTML content from Rich Text Editor
  gambarTtd: string; // Base64 image
  namaPimpinan: string;
  jabatan: string;
  tembusan: string; // multiline
  createdAt: string;
}

export interface EmailJSConfig {
  serviceId: string;
  templateId: string;
  publicKey: string;
}

export interface SavedLetter extends LetterData {
  status: 'Draft' | 'Terkirim' | 'Selesai';
}
