/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { BookOpen, AlertCircle, CheckCircle, Info, ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';

interface PartExplanation {
  id: string;
  name: string;
  rules: string[];
  mistakes: string[];
  example: string;
}

const LETTER_PARTS: Record<string, PartExplanation> = {
  kop: {
    id: 'kop',
    name: 'Kop Surat (Kepala Surat)',
    rules: [
      'Memuat nama instansi resmi, logo, alamat lengkap, nomor telepon, dan email.',
      'Ditulis dengan huruf kapital untuk nama instansi utama.',
      'Dipisahkan dengan garis pembatas tebal-tipis (double line) di bagian bawah.'
    ],
    mistakes: [
      'Menulis kata "Jalan" disingkat menjadi "Jl." dalam dokumen sangat resmi (disarankan menulis lengkap "Jalan").',
      'Ukuran logo terlalu besar atau pecah (low resolution).',
      'Garis pembatas tidak rapi atau terlalu dekat dengan teks alamat.'
    ],
    example: 'KEMENTERIAN PENDIDIKAN, KEBUDAYAAN, RISET, DAN TEKNOLOGI\nSMK NEGERI 1 JAKARTA\nJalan Pemuda No. 10, Rawamangun, Jakarta Timur'
  },
  nomor: {
    id: 'nomor',
    name: 'Nomor, Lampiran, dan Perihal',
    rules: [
      'Nomor surat diisi sesuai kode pengarsipan instansi.',
      'Lampiran diisi jumlah berkas yang disertakan (contoh: "1 berkas" atau "-" jika tidak ada).',
      'Perihal mencerminkan inti/tujuan utama penulisan surat secara singkat.'
    ],
    mistakes: [
      'Menulis kata "Perihal" disingkat "Hal" namun tidak konsisten.',
      'Format nomor surat tidak runtut sesuai buku agenda surat keluar.'
    ],
    example: 'Nomor: 421.3/SMK-ADM/VII/2026\nLampiran: 1 Berkas\nPerihal: Undangan Sosialisasi PKL'
  },
  tanggal: {
    id: 'tanggal',
    name: 'Tanggal Surat',
    rules: [
      'Tanggal surat diletakkan di sebelah kanan sejajar dengan nomor surat atau di atas perihal jika tanpa kop.',
      'Nama kota tidak perlu ditulis jika sudah ada pada Kop Surat resmi.',
      'Nama bulan ditulis lengkap (bukan angka/singkatan) dan tahun ditulis utuh.'
    ],
    mistakes: [
      'Menambahkan nama kota padahal surat memiliki Kop Surat resmi (contoh salah: "Jakarta, 12 Juli 2026" - harusnya "12 Juli 2026" saja).',
      'Menyingkat nama bulan (contoh: "Jul" atau "07").'
    ],
    example: '6 Juli 2026'
  },
  penerima: {
    id: 'penerima',
    name: 'Alamat Penerima (Kepada)',
    rules: [
      'Menggunakan kata "Yth." diikuti nama jabatan atau nama orang.',
      'Hindari menggunakan kata sapaan (Bapak/Ibu) jika diikuti jabatan (contoh benar: "Yth. Kepala Sekolah", contoh salah: "Yth. Bapak Kepala Sekolah").',
      'Kata "di" diletakkan sebelum nama tempat/kota.'
    ],
    mistakes: [
      'Menggunakan kata "Kepada" sebelum "Yth." (pilih salah satu, biasanya langsung "Yth.").',
      'Menulis "di Tempat" dengan huruf kecil ("di tempat").'
    ],
    example: 'Yth. Pimpinan PT Nusantara Jaya\nJalan Asia Afrika No. 100\nBandung'
  },
  pembuka: {
    id: 'pembuka',
    name: 'Salam & Paragraf Pembuka',
    rules: [
      'Salam pembuka menggunakan frasa resmi "Dengan hormat," diakhiri koma.',
      'Paragraf pembuka berfungsi sebagai pengantar konteks atau dasar penulisan surat.'
    ],
    mistakes: [
      'Menulis salam pembuka non-formal atau terlalu panjang.',
      'Mengabaikan tanda koma setelah kalimat "Dengan hormat".'
    ],
    example: 'Dengan hormat,\n\nSehubungan dengan akan dilaksanakannya kegiatan Praktik Kerja Lapangan...'
  },
  isi: {
    id: 'isi',
    name: 'Isi Surat Utama',
    rules: [
      'Menggunakan bahasa Indonesia baku (sesuai EYD/PUEBI).',
      'Singkat, padat, jelas, langsung pada inti maksud surat.',
      'Gunakan bullet/numbering untuk merinci detail (hari, tanggal, waktu, tempat).'
    ],
    mistakes: [
      'Bahasa bertele-tele atau ambigu.',
      'Kesalahan penulisan detail hari, tanggal, atau waktu kegiatan.'
    ],
    example: 'Mengharap kehadiran Bapak/Ibu pada:\nHari/Tanggal: Senin, 13 Juli 2026\nWaktu: 09.00 WIB\nTempat: Aula SMK'
  },
  penutup: {
    id: 'penutup',
    name: 'Paragraf & Salam Penutup',
    rules: [
      'Berisi ucapan terima kasih dan harapan atas tindak lanjut surat.',
      'Gunakan kalimat yang efektif dan sopan.'
    ],
    mistakes: [
      'Kalimat penutup yang berlebihan (contoh salah: "Atas perhatiannya kami ucapkan beribu terima kasih").',
      'Menggunakan kata ganti "-nya" untuk merujuk pada penerima (gunakan nama jabatan/sapaan).'
    ],
    example: 'Demikian undangan ini kami sampaikan. Atas perhatian dan kehadiran Bapak/Ibu, kami mengucapkan terima kasih.'
  },
  ttd: {
    id: 'ttd',
    name: 'Tanda Tangan & Nama Pimpinan',
    rules: [
      'Menuliskan nama jabatan pimpinan yang berwenang.',
      'Menyisipkan tanda tangan fisik/digital yang valid.',
      'Nama lengkap pimpinan ditulis jelas dengan gelar akademik lengkap, di bawahnya ditambahkan NIP jika ada.'
    ],
    mistakes: [
      'Nama pimpinan ditulis menggunakan huruf kapital semua tanpa tanda kurung/garis bawah (disesuaikan aturan instansi).',
      'Tanda tangan menutupi nama pimpinan sehingga tidak terbaca.'
    ],
    example: 'Kepala Sekolah,\n\n[TANDA TANGAN]\n\nDrs. H. Ahmad Sudrajat, M.Pd.\nNIP. 19750812 200003 1 002'
  },
  tembusan: {
    id: 'tembusan',
    name: 'Tembusan',
    rules: [
      'Digunakan jika surat perlu diketahui oleh pihak lain yang terkait.',
      'Ditulis di bagian kiri bawah setelah nama pimpinan.',
      'Tidak menggunakan kata "Kepada Yth." dalam tembusan.'
    ],
    mistakes: [
      'Menuliskan tembusan padahal tidak ada pihak ketiga yang perlu menerima arsip.',
      'Menulis kata "Arsip" sebagai tembusan nomor 1 (arsip diletakkan di nomor terakhir).'
    ],
    example: 'Tembusan:\n1. Ketua Yayasan Pendidikan\n2. Arsip'
  }
};

export default function PanduanBelajar() {
  const [activePart, setActivePart] = useState<PartExplanation>(LETTER_PARTS.kop);

  return (
    <div className="space-y-8" id="panduan-belajar-root">
      {/* Intro Header */}
      <div className="bg-gradient-to-r from-[#0F4C81]/90 to-[#0F4C81] text-white p-6 md:p-8 rounded-2xl shadow-xl flex flex-col md:flex-row items-center gap-6 border border-white/10 backdrop-blur-md">
        <div className="bg-[#FFC857] text-[#0F4C81] p-4 rounded-xl shadow-lg">
          <BookOpen size={36} className="animate-pulse" />
        </div>
        <div className="text-center md:text-left flex-1">
          <h2 className="text-2xl font-bold font-sans tracking-tight">Modul Belajar: Sistematika Surat Dinas</h2>
          <p className="text-blue-100 mt-2 max-w-xl text-sm md:text-base">
            Klik atau pilih komponen surat pada visualisasi interaktif di bawah ini untuk mempelajari aturan penulisan resmi, kesalahan umum, dan contoh formatnya.
          </p>
        </div>
        <div className="flex flex-wrap gap-2 justify-center">
          <span className="bg-white/10 text-white text-xs px-3 py-1.5 rounded-full font-mono border border-white/20">
            ★ Sesuai PUEBI & EYD
          </span>
          <span className="bg-[#FFC857]/20 text-[#FFC857] text-xs px-3 py-1.5 rounded-full font-mono border border-[#FFC857]/30">
            ✓ Kurikulum SMK MP
          </span>
        </div>
      </div>

      {/* Main Educational Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Interactive Visual Selector (Left side: 5 cols) */}
        <div className="lg:col-span-5 bg-white p-6 rounded-2xl shadow-lg border border-gray-100 flex flex-col h-full min-h-[500px]">
          <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#0F4C81]" />
            Visualisasi Struktur Surat
          </h3>
          
          {/* Virtual Paper Representation */}
          <div className="flex-1 bg-gray-50 border border-gray-200 rounded-xl p-4 flex flex-col gap-2 font-mono text-[9px] relative overflow-hidden shadow-inner">
            
            {/* Kop Surat Spot */}
            <button
              onClick={() => setActivePart(LETTER_PARTS.kop)}
              className={`w-full text-center p-2 rounded-lg border transition-all ${
                activePart.id === 'kop'
                  ? 'bg-[#0F4C81]/15 border-[#0F4C81] shadow-sm text-[#0F4C81] font-bold scale-[1.02]'
                  : 'bg-white hover:bg-gray-100 border-gray-200 text-gray-500'
              }`}
            >
              [ KEPALA / KOP SURAT INSTANSI RESMI ]
              <div className="text-[7px] font-normal opacity-75 mt-0.5">Logo, Nama Instansi, Alamat Lengkap</div>
            </button>

            {/* Split double line */}
            <div className="border-t-2 border-b border-gray-400 my-1 h-0.5" />

            {/* Row: Nomor and Tanggal */}
            <div className="grid grid-cols-2 gap-2 my-1">
              <button
                onClick={() => setActivePart(LETTER_PARTS.nomor)}
                className={`text-left p-1.5 rounded border transition-all ${
                  activePart.id === 'nomor'
                    ? 'bg-[#0F4C81]/15 border-[#0F4C81] shadow-sm text-[#0F4C81] font-bold scale-[1.02]'
                    : 'bg-white hover:bg-gray-100 border-gray-200 text-gray-500'
                }`}
              >
                <div>Nomor: 421.3/...</div>
                <div>Lampiran: 1 Berkas</div>
                <div>Hal: Perihal Surat</div>
              </button>

              <button
                onClick={() => setActivePart(LETTER_PARTS.tanggal)}
                className={`text-right p-1.5 rounded border transition-all self-start ${
                  activePart.id === 'tanggal'
                    ? 'bg-[#0F4C81]/15 border-[#0F4C81] shadow-sm text-[#0F4C81] font-bold scale-[1.02]'
                    : 'bg-white hover:bg-gray-100 border-gray-200 text-gray-500'
                }`}
              >
                6 Juli 2026
                <div className="text-[7px] font-normal opacity-75 mt-0.5">Tanggal Surat</div>
              </button>
            </div>

            {/* Alamat Penerima */}
            <button
              onClick={() => setActivePart(LETTER_PARTS.penerima)}
              className={`w-1/2 text-left p-1.5 rounded border transition-all my-1 ${
                activePart.id === 'penerima'
                  ? 'bg-[#0F4C81]/15 border-[#0F4C81] shadow-sm text-[#0F4C81] font-bold scale-[1.02]'
                  : 'bg-white hover:bg-gray-100 border-gray-200 text-gray-500'
              }`}
            >
              Yth. Penerima Surat
              <br />Alamat Lengkap
              <br />di Tempat
            </button>

            {/* Salam & Pembuka */}
            <button
              onClick={() => setActivePart(LETTER_PARTS.pembuka)}
              className={`w-full text-left p-1.5 rounded border transition-all ${
                activePart.id === 'pembuka'
                  ? 'bg-[#0F4C81]/15 border-[#0F4C81] shadow-sm text-[#0F4C81] font-bold scale-[1.02]'
                  : 'bg-white hover:bg-gray-100 border-gray-200 text-gray-500'
              }`}
            >
              Dengan hormat,
              <div className="text-[7px] font-normal opacity-75 mt-0.5">Paragraf Pembuka / Pengantar Konteks</div>
            </button>

            {/* Isi Surat */}
            <button
              onClick={() => setActivePart(LETTER_PARTS.isi)}
              className={`w-full text-left p-2 rounded border transition-all h-20 flex flex-col justify-between ${
                activePart.id === 'isi'
                  ? 'bg-[#0F4C81]/15 border-[#0F4C81] shadow-sm text-[#0F4C81] font-bold scale-[1.02]'
                  : 'bg-white hover:bg-gray-100 border-gray-200 text-gray-500'
              }`}
            >
              <div>[ PARAGRAF ISI UTAMA ]</div>
              <div className="text-[7px] font-normal opacity-75">Detail Acara/Maksud (Hari, Tanggal, Waktu, Tempat) menggunakan rincian bullet / numbering.</div>
            </button>

            {/* Penutup */}
            <button
              onClick={() => setActivePart(LETTER_PARTS.penutup)}
              className={`w-full text-left p-1.5 rounded border transition-all ${
                activePart.id === 'penutup'
                  ? 'bg-[#0F4C81]/15 border-[#0F4C81] shadow-sm text-[#0F4C81] font-bold scale-[1.02]'
                  : 'bg-white hover:bg-gray-100 border-gray-200 text-gray-500'
              }`}
            >
              Demikian surat ini kami sampaikan...
              <div className="text-[7px] font-normal opacity-75 mt-0.5">Paragraf Penutup & Salam Terima Kasih</div>
            </button>

            {/* Row: Tembusan & TTD */}
            <div className="grid grid-cols-2 gap-2 mt-auto pt-2">
              <button
                onClick={() => setActivePart(LETTER_PARTS.tembusan)}
                className={`text-left p-1.5 rounded border transition-all self-end ${
                  activePart.id === 'tembusan'
                    ? 'bg-[#0F4C81]/15 border-[#0F4C81] shadow-sm text-[#0F4C81] font-bold scale-[1.02]'
                    : 'bg-white hover:bg-gray-100 border-gray-200 text-gray-500'
                }`}
              >
                Tembusan:
                <br />1. Pihak Terkait
                <br />2. Arsip
              </button>

              <button
                onClick={() => setActivePart(LETTER_PARTS.ttd)}
                className={`text-center p-1.5 rounded border transition-all ${
                  activePart.id === 'ttd'
                    ? 'bg-[#0F4C81]/15 border-[#0F4C81] shadow-sm text-[#0F4C81] font-bold scale-[1.02]'
                    : 'bg-white hover:bg-gray-100 border-gray-200 text-gray-500'
                }`}
              >
                Kepala Instansi,
                <div className="my-1 border-b border-dashed border-gray-300 py-2 text-[7px] text-gray-400">[ Tanda Tangan ]</div>
                <strong>Nama Jelas Pimpinan</strong>
                <div className="text-[7px] font-normal opacity-75">NIP. 19750...</div>
              </button>
            </div>

          </div>
          
          <p className="text-xs text-gray-400 mt-3 text-center italic">
            💡 Tips: Klik bagian surat di atas untuk melihat panduan lengkapnya.
          </p>
        </div>

        {/* Detailed Explanation Panel (Right side: 7 cols) */}
        <div className="lg:col-span-7 flex flex-col gap-6">
          
          {/* Main Card */}
          <motion.div
            key={activePart.id}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className="bg-white p-6 md:p-8 rounded-2xl shadow-lg border border-gray-100 space-y-6 flex-1 flex flex-col justify-between"
          >
            <div>
              {/* Part Name Header */}
              <div className="flex items-center justify-between border-b border-gray-100 pb-4">
                <h4 className="text-xl font-bold text-[#0F4C81] flex items-center gap-3">
                  <span className="p-2 bg-[#0F4C81]/10 rounded-lg text-[#0F4C81]">
                    <Info size={20} />
                  </span>
                  {activePart.name}
                </h4>
                <span className="bg-gray-100 text-gray-500 text-xs px-3 py-1 rounded-full font-mono">
                  Sistematika #{Object.keys(LETTER_PARTS).indexOf(activePart.id) + 1}
                </span>
              </div>

              {/* Aturan Penulisan (Rules) */}
              <div className="mt-6 space-y-3">
                <h5 className="font-bold text-gray-800 text-sm flex items-center gap-2">
                  <CheckCircle size={16} className="text-green-500" />
                  Aturan Penulisan Resmi (Standar Administrasi)
                </h5>
                <ul className="list-disc pl-5 text-gray-600 text-sm space-y-2 leading-relaxed">
                  {activePart.rules.map((rule, idx) => (
                    <li key={idx}>{rule}</li>
                  ))}
                </ul>
              </div>

              {/* Kesalahan Umum (Mistakes) */}
              <div className="mt-6 space-y-3 bg-red-50/50 p-4 rounded-xl border border-red-100">
                <h5 className="font-bold text-red-800 text-sm flex items-center gap-2">
                  <AlertCircle size={16} className="text-red-500" />
                  Kesalahan Umum Siswa / Pemula
                </h5>
                <ul className="list-disc pl-5 text-red-700 text-xs space-y-1.5 leading-relaxed">
                  {activePart.mistakes.map((mistake, idx) => (
                    <li key={idx}>{mistake}</li>
                  ))}
                </ul>
              </div>

              {/* Contoh Penulisan */}
              <div className="mt-6 space-y-2">
                <h5 className="font-bold text-gray-800 text-sm">Contoh Teks Format Baku:</h5>
                <pre className="bg-gray-50 text-gray-700 p-4 rounded-xl text-xs font-mono border border-gray-200 overflow-x-auto leading-relaxed whitespace-pre-line">
                  {activePart.example}
                </pre>
              </div>
            </div>

            {/* Next buttons for easy navigation */}
            <div className="flex justify-between items-center pt-6 border-t border-gray-100 mt-6">
              <span className="text-xs text-gray-400">Belajar sistematika persuratan SMK</span>
              <button
                onClick={() => {
                  const keys = Object.keys(LETTER_PARTS);
                  const nextIndex = (keys.indexOf(activePart.id) + 1) % keys.length;
                  setActivePart(LETTER_PARTS[keys[nextIndex]]);
                }}
                className="flex items-center gap-1 bg-[#0F4C81] hover:bg-[#0C3C66] text-white text-xs px-4 py-2.5 rounded-xl font-medium shadow-md transition-all hover:translate-x-1"
              >
                Sistematika Berikutnya
                <ArrowRight size={14} />
              </button>
            </div>
          </motion.div>
        </div>

      </div>

      {/* Quick Quiz Card for Pedagogical Value */}
      <div className="bg-amber-50/50 border border-amber-200 p-6 rounded-2xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="space-y-1">
          <h4 className="font-bold text-amber-800 text-base flex items-center gap-2">
            💡 Tips Tambahan untuk Prakerin / PKL:
          </h4>
          <p className="text-amber-700 text-sm max-w-2xl leading-relaxed">
            Saat menyerahkan surat fisik ke perusahaan tempat magang, selalu pastikan surat terlipat rapi menggunakan teknik lipatan <strong>Standard Fold</strong> atau <strong>Low Accordion Fold</strong>, dan simpan dalam map plastik bersih.
          </p>
        </div>
        <button 
          onClick={() => {
            const keys = Object.keys(LETTER_PARTS);
            setActivePart(LETTER_PARTS[keys[0]]);
            const el = document.getElementById('panduan-belajar-root');
            if (el) el.scrollIntoView({ behavior: 'smooth' });
          }}
          className="bg-amber-500 hover:bg-amber-600 text-white text-xs px-4 py-2.5 rounded-xl font-semibold shadow-sm shrink-0 transition-colors"
        >
          Ulangi Panduan
        </button>
      </div>
    </div>
  );
}
