/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { LetterData, EmailJSConfig, SavedLetter } from '../types';
import { 
  FileText, Trash2, Download, Printer, Mail, ZoomIn, ZoomOut, 
  Maximize2, Undo, Redo, RefreshCw, Upload, Sparkles, Check, 
  Settings, Info, Moon, Sun, Minimize2, Bold, Italic, Underline,
  List, ListOrdered, AlignLeft, HelpCircle
} from 'lucide-react';
import Swal from 'sweetalert2';
import { downloadLetterPDF, getPDFBase64 } from '../services/pdfService';
import { sendLetterEmail } from '../services/emailService';
import { TEMPLATE_SURAT, DEFAULT_LOGO_SVG, DEFAULT_TTD_SVG } from '../utils/defaultData';
import { motion, AnimatePresence } from 'motion/react';

interface GeneratorProps {
  initialLetterData: SavedLetter | null;
  onSavedTrigger: () => void;
}

export default function Generator({ initialLetterData, onSavedTrigger }: GeneratorProps) {
  // Main form state
  const [formData, setFormData] = useState<LetterData>({
    id: '',
    nomorSurat: '',
    namaInstansi: '',
    kopSurat: '',
    logoInstansi: '',
    tanggalSurat: '',
    kepada: '',
    isiSurat: '',
    gambarTtd: '',
    namaPimpinan: '',
    jabatan: '',
    tembusan: '',
    createdAt: '',
  });

  // Validation state
  const [errors, setErrors] = useState<Record<string, string>>({});

  // History state for Undo / Redo
  const [history, setHistory] = useState<LetterData[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const isTransitioningHistory = useRef(false);

  // Layout zoom state
  const [zoomLevel, setZoomLevel] = useState(100);

  // Fullscreen preview modal state
  const [isFullscreen, setIsFullscreen] = useState(false);

  // Preview Dark Mode state
  const [previewDarkMode, setPreviewDarkMode] = useState(false);

  // Email popup modal state
  const [isEmailModalOpen, setIsEmailModalOpen] = useState(false);
  const [emailForm, setEmailForm] = useState({
    to_email: '',
    subject: 'Surat Dinas Resmi - Smart Letter Generator',
    message: 'Selamat pagi/siang,\n\nBerikut kami lampirkan dokumen surat dinas resmi yang digenerate menggunakan aplikasi pembelajaran Smart Letter Generator.\n\nTerima kasih.',
  });
  const [isSendingEmail, setIsSendingEmail] = useState(false);

  // Settings for EmailJS (persist in Local Storage)
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [emailConfig, setEmailConfig] = useState<EmailJSConfig>({
    serviceId: '',
    templateId: '',
    publicKey: '',
  });

  // Ref for PDF printing / rendering
  const previewRef = useRef<HTMLDivElement>(null);
  
  // Custom rich text editor ref / selection state
  const editorRef = useRef<HTMLDivElement>(null);

  // Initial load
  useEffect(() => {
    // Load EmailJS config from LocalStorage if exists
    const savedConfig = localStorage.getItem('smart_letter_emailjs');
    if (savedConfig) {
      setEmailConfig(JSON.parse(savedConfig));
    }

    if (initialLetterData) {
      // Load passed editing letter
      updateStateWithHistory(initialLetterData);
      Swal.fire({
        title: 'Surat Dimuat!',
        text: 'Anda sedang mengubah surat dari riwayat.',
        icon: 'info',
        timer: 1500,
        showConfirmButton: false
      });
    } else {
      // Auto-load last drafted data if exists, else load a default template
      const lastDraft = localStorage.getItem('smart_letter_draft');
      if (lastDraft) {
        try {
          updateStateWithHistory(JSON.parse(lastDraft));
        } catch (e) {
          loadTemplate('undanganRapat');
        }
      } else {
        loadTemplate('undanganRapat');
      }
    }
  }, [initialLetterData]);

  // Update editor ref innerHTML when state is loaded/modified from outside
  useEffect(() => {
    if (editorRef.current && editorRef.current.innerHTML !== formData.isiSurat) {
      editorRef.current.innerHTML = formData.isiSurat;
    }
  }, [formData.isiSurat]);

  // Auto-save draft on every modification
  useEffect(() => {
    if (formData.id) {
      localStorage.setItem('smart_letter_draft', JSON.stringify(formData));
    }
  }, [formData]);

  // Handle field change and record history
  const handleFieldChange = (field: keyof LetterData, value: string) => {
    const updated = { ...formData, [field]: value };
    setFormData(updated);

    // Clear specific error
    if (errors[field]) {
      setErrors(prev => {
        const next = { ...prev };
        delete next[field];
        return next;
      });
    }

    // Save to Undo/Redo history
    if (!isTransitioningHistory.current) {
      const newHistory = history.slice(0, historyIndex + 1);
      newHistory.push(updated);
      
      // Cap history size to 30 elements
      if (newHistory.length > 30) {
        newHistory.shift();
      }
      
      setHistory(newHistory);
      setHistoryIndex(newHistory.length - 1);
    }
  };

  // Safe State Updating with History Tracking
  const updateStateWithHistory = (newState: LetterData) => {
    isTransitioningHistory.current = true;
    setFormData(newState);
    
    const newHistory = [newState];
    setHistory(newHistory);
    setHistoryIndex(0);
    
    setTimeout(() => {
      isTransitioningHistory.current = false;
    }, 50);
  };

  // Undo Function
  const handleUndo = () => {
    if (historyIndex > 0) {
      isTransitioningHistory.current = true;
      const prevIndex = historyIndex - 1;
      setFormData(history[prevIndex]);
      setHistoryIndex(prevIndex);
      setTimeout(() => {
        isTransitioningHistory.current = false;
      }, 50);
    }
  };

  // Redo Function
  const handleRedo = () => {
    if (historyIndex < history.length - 1) {
      isTransitioningHistory.current = true;
      const nextIndex = historyIndex + 1;
      setFormData(history[nextIndex]);
      setHistoryIndex(nextIndex);
      setTimeout(() => {
        isTransitioningHistory.current = false;
      }, 50);
    }
  };

  // Apply Template helper
  const loadTemplate = (templateKey: 'undanganRapat' | 'permohonanPkl') => {
    const base = TEMPLATE_SURAT[templateKey];
    const freshData: LetterData = {
      id: 'letter_' + Date.now(),
      nomorSurat: base.nomorSurat || '',
      namaInstansi: base.namaInstansi || '',
      kopSurat: base.kopSurat || '',
      logoInstansi: DEFAULT_LOGO_SVG,
      tanggalSurat: base.tanggalSurat || new Date().toISOString().split('T')[0],
      kepada: base.kepada || '',
      isiSurat: base.isiSurat || '',
      gambarTtd: DEFAULT_TTD_SVG,
      namaPimpinan: base.namaPimpinan || '',
      jabatan: base.jabatan || '',
      tembusan: base.tembusan || '',
      createdAt: new Date().toISOString(),
    };
    updateStateWithHistory(freshData);
  };

  // Handle image uploads (Logo and TTD)
  const handleImageUpload = (field: 'logoInstansi' | 'gambarTtd', file: File) => {
    if (!file.type.startsWith('image/')) {
      Swal.fire('Format Salah', 'Harap unggah file gambar (PNG, JPG, SVG).', 'warning');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      if (e.target?.result) {
        handleFieldChange(field, e.target.result as string);
      }
    };
    reader.readAsDataURL(file);
  };

  // Reset function with Confirmation
  const handleReset = () => {
    Swal.fire({
      title: 'Kosongkan Form?',
      text: 'Semua teks input surat yang sedang diketik akan diatur ulang menjadi kosong.',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#d33',
      cancelButtonColor: '#3085d6',
      confirmButtonText: 'Ya, Kosongkan!',
      cancelButtonText: 'Batal'
    }).then((result) => {
      if (result.isConfirmed) {
        const resetData: LetterData = {
          id: 'letter_' + Date.now(),
          nomorSurat: '',
          namaInstansi: '',
          kopSurat: '',
          logoInstansi: '',
          tanggalSurat: '',
          kepada: '',
          isiSurat: '',
          gambarTtd: '',
          namaPimpinan: '',
          jabatan: '',
          tembusan: '',
          createdAt: new Date().toISOString(),
        };
        updateStateWithHistory(resetData);
        if (editorRef.current) {
          editorRef.current.innerHTML = '';
        }
        setErrors({});
        Swal.fire('Berhasil!', 'Formulir telah dikosongkan.', 'success');
      }
    });
  };

  // Save Config function
  const handleSaveEmailConfig = () => {
    localStorage.setItem('smart_letter_emailjs', JSON.stringify(emailConfig));
    setIsSettingsOpen(false);
    Swal.fire({
      title: 'Tersimpan!',
      text: 'Kunci EmailJS Anda berhasil dikonfigurasi secara lokal.',
      icon: 'success',
      timer: 1500,
      showConfirmButton: false
    });
  };

  // Form Validation helper
  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};
    const requiredFields: Array<keyof LetterData> = [
      'nomorSurat', 'namaInstansi', 'tanggalSurat', 'kepada', 
      'isiSurat', 'namaPimpinan', 'jabatan'
    ];

    requiredFields.forEach(field => {
      if (!formData[field] || formData[field].trim() === '') {
        newErrors[field] = 'Kolom ini wajib diisi oleh siswa.';
      }
    });

    setErrors(newErrors);

    if (Object.keys(newErrors).length > 0) {
      Swal.fire({
        title: 'Formulir Belum Lengkap',
        text: 'Silakan lengkapi semua kolom yang ditandai merah terlebih dahulu.',
        icon: 'error',
        confirmButtonColor: '#0F4C81'
      });
      return false;
    }
    return true;
  };

  // Save to LocalStorage History (Generate Surat)
  const handleGenerateSurat = () => {
    if (!validateForm()) return;

    try {
      const stored = localStorage.getItem('smart_letter_saved');
      let savedList: SavedLetter[] = stored ? JSON.parse(stored) : [];

      // Check if letter already exists (updating)
      const existingIdx = savedList.findIndex(l => l.id === formData.id);
      
      const newLetter: SavedLetter = {
        ...formData,
        status: existingIdx >= 0 ? savedList[existingIdx].status : 'Draft',
        createdAt: new Date().toISOString()
      };

      if (existingIdx >= 0) {
        savedList[existingIdx] = newLetter;
      } else {
        savedList.unshift(newLetter);
      }

      localStorage.setItem('smart_letter_saved', JSON.stringify(savedList));
      onSavedTrigger(); // Notify dashboard/history page to refresh
      
      Swal.fire({
        title: 'Berhasil Digenerate!',
        text: 'Surat telah divalidasi dan disimpan ke Riwayat Surat lokal Anda.',
        icon: 'success',
        confirmButtonColor: '#0F4C81'
      });
    } catch (e) {
      Swal.fire('Gagal Menyimpan', 'Terjadi kesalahan sistem penyimpanan lokal.', 'error');
    }
  };

  // Download PDF Action
  const handleDownloadPDF = async () => {
    if (!validateForm()) return;

    Swal.fire({
      title: 'Menyiapkan PDF...',
      html: 'Mengonversi komponen tata letak surat ke format dokumen HD.',
      didOpen: () => {
        Swal.showLoading();
      },
      allowOutsideClick: false
    });

    try {
      await downloadLetterPDF('letter-preview-card', formData.nomorSurat);
      Swal.fire({
        title: 'Berhasil!',
        text: 'PDF surat dinas berhasil diunduh.',
        icon: 'success',
        timer: 1500,
        showConfirmButton: false
      });
    } catch (e: any) {
      Swal.fire('Gagal Konversi', 'Terjadi kesalahan perenderan PDF: ' + e.message, 'error');
    }
  };

  // Print Action using Native Print and CSS
  const handlePrint = () => {
    if (!validateForm()) return;
    window.print();
  };

  // Send Email Action (Triggers EmailJS flow)
  const handleSendEmail = async () => {
    if (!validateForm()) return;

    // Check if configuration exists
    if (!emailConfig.serviceId || !emailConfig.templateId || !emailConfig.publicKey) {
      Swal.fire({
        title: 'Pengaturan EmailJS Dibutuhkan',
        text: 'Anda perlu mengonfigurasi Service ID, Template ID, dan Public Key EmailJS Anda melalui panel pengaturan di kanan atas formulir.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Buka Pengaturan',
        cancelButtonText: 'Batal',
        confirmButtonColor: '#0F4C81'
      }).then(res => {
        if (res.isConfirmed) {
          setIsSettingsOpen(true);
        }
      });
      return;
    }

    setIsEmailModalOpen(true);
  };

  const handleConfirmSendEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!emailForm.to_email) {
      Swal.fire('Input Salah', 'Harap masukkan alamat email penerima.', 'warning');
      return;
    }

    setIsSendingEmail(true);
    
    try {
      // Get PDF base64 data to attach
      const pdfBase64 = await getPDFBase64('letter-preview-card');

      await sendLetterEmail(emailConfig, {
        to_email: emailForm.to_email,
        subject: emailForm.subject,
        message: emailForm.message,
        nomorSurat: formData.nomorSurat,
        namaInstansi: formData.namaInstansi,
        namaPimpinan: formData.namaPimpinan,
        letterHtmlContent: formData.isiSurat,
        pdfDataUrl: pdfBase64
      });

      // Update status in history to "Terkirim"
      const stored = localStorage.getItem('smart_letter_saved');
      if (stored) {
        let savedList: SavedLetter[] = JSON.parse(stored);
        const letterIdx = savedList.findIndex(l => l.id === formData.id);
        if (letterIdx >= 0) {
          savedList[letterIdx].status = 'Terkirim';
          localStorage.setItem('smart_letter_saved', JSON.stringify(savedList));
          onSavedTrigger();
        }
      }

      setIsEmailModalOpen(false);
      Swal.fire({
        title: 'Email Terkirim!',
        text: 'Surat dinas beserta lampiran PDF telah berhasil dikirim ke: ' + emailForm.to_email,
        icon: 'success',
        confirmButtonColor: '#0F4C81'
      });
    } catch (err: any) {
      Swal.fire('Pengiriman Gagal', err.message, 'error');
    } finally {
      setIsSendingEmail(false);
    }
  };

  // Rich Text Editor Commands (using document.execCommand)
  const executeEditorCommand = (command: string, value: string = '') => {
    document.execCommand(command, false, value);
    if (editorRef.current) {
      handleFieldChange('isiSurat', editorRef.current.innerHTML);
    }
  };

  // Drag and Drop drag over handlers
  const [dragActiveLogo, setDragActiveLogo] = useState(false);
  const [dragActiveTtd, setDragActiveTtd] = useState(false);

  // Character counter helper
  const charCount = formData.isiSurat.replace(/<[^>]*>/g, '').length;

  return (
    <div className="grid grid-cols-1 xl:grid-cols-12 gap-8" id="generator-container-root">
      
      {/* LEFT COLUMN: Input Form (5 Cols) */}
      <div className="xl:col-span-5 flex flex-col gap-6 print:hidden">
        
        {/* Form Panel Header */}
        <div className="bg-white p-6 rounded-2xl shadow-lg border border-gray-100 space-y-4">
          <div className="flex justify-between items-center border-b border-gray-100 pb-3">
            <h3 className="text-base font-bold text-gray-800 flex items-center gap-2">
              <Sparkles className="text-[#FFC857]" size={18} />
              Formulir Input Surat
            </h3>
            
            {/* Template Selector & Config Row */}
            <div className="flex gap-1.5">
              <button
                onClick={() => setIsSettingsOpen(!isSettingsOpen)}
                className="p-1.5 hover:bg-gray-100 text-gray-400 hover:text-gray-600 rounded-lg transition-colors"
                title="Konfigurasi EmailJS"
              >
                <Settings size={16} />
              </button>
              
              <button
                onClick={handleUndo}
                disabled={historyIndex <= 0}
                className="p-1.5 hover:bg-gray-100 text-gray-400 hover:text-gray-600 disabled:opacity-30 rounded-lg transition-colors"
                title="Undo (Urungkan)"
              >
                <Undo size={16} />
              </button>

              <button
                onClick={handleRedo}
                disabled={historyIndex >= history.length - 1}
                className="p-1.5 hover:bg-gray-100 text-gray-400 hover:text-gray-600 disabled:opacity-30 rounded-lg transition-colors"
                title="Redo (Ulangi)"
              >
                <Redo size={16} />
              </button>
            </div>
          </div>

          {/* Quick template quick loads */}
          <div className="space-y-1.5">
            <label className="text-[10px] uppercase tracking-wider font-extrabold text-gray-400 flex items-center gap-1">
              <Info size={10} />
              Pilih Contoh Surat (Template Pembelajaran):
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => loadTemplate('undanganRapat')}
                className="text-center px-3 py-2 bg-blue-50/50 hover:bg-[#0F4C81]/10 text-[#0F4C81] border border-[#0F4C81]/20 rounded-xl text-xs font-semibold transition-all hover:translate-y-[-1px]"
              >
                ✉ Undangan Rapat
              </button>
              <button
                onClick={() => loadTemplate('permohonanPkl')}
                className="text-center px-3 py-2 bg-amber-50/50 hover:bg-[#FFC857]/15 text-amber-800 border border-[#FFC857]/30 rounded-xl text-xs font-semibold transition-all hover:translate-y-[-1px]"
              >
                💼 Permohonan PKL
              </button>
            </div>
          </div>
        </div>

        {/* Form Body Fields - Editorial Aesthetic Theme */}
        <div className="bg-white p-6 rounded-[14px] shadow-lg border border-slate-200/80 space-y-5">
          
          {/* Row 1: Nomor Surat & Tanggal */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider block">Nomor Surat <span className="text-red-500">*</span></label>
              <input
                type="text"
                placeholder="Contoh: 421/SMK/VI/2026"
                className={`w-full px-4 py-2.5 border rounded-[14px] text-sm focus:ring-2 focus:ring-[#0F4C81] focus:border-transparent transition-all outline-none ${
                  errors.nomorSurat ? 'border-red-500 bg-red-50/30' : 'border-slate-200 bg-slate-50'
                }`}
                value={formData.nomorSurat}
                onChange={(e) => handleFieldChange('nomorSurat', e.target.value)}
              />
              {errors.nomorSurat && <p className="text-[10px] text-red-500 font-medium">{errors.nomorSurat}</p>}
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider block">Tanggal Surat <span className="text-red-500">*</span></label>
              <input
                type="date"
                className={`w-full px-4 py-2 border rounded-[14px] text-sm focus:ring-2 focus:ring-[#0F4C81] focus:border-transparent transition-all outline-none ${
                  errors.tanggalSurat ? 'border-red-500 bg-red-50/30' : 'border-slate-200 bg-slate-50'
                }`}
                value={formData.tanggalSurat}
                onChange={(e) => handleFieldChange('tanggalSurat', e.target.value)}
              />
              {errors.tanggalSurat && <p className="text-[10px] text-red-500 font-medium">{errors.tanggalSurat}</p>}
            </div>
          </div>

          {/* Row 2: Nama Instansi */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-500 uppercase tracking-wider block">Nama Instansi Resmi <span className="text-red-500">*</span></label>
            <input
              type="text"
              placeholder="Contoh: SMK NEGERI 1 JAKARTA"
              className={`w-full px-4 py-2.5 border rounded-[14px] text-sm focus:ring-2 focus:ring-[#0F4C81] focus:border-transparent transition-all outline-none ${
                errors.namaInstansi ? 'border-red-500 bg-red-50/30' : 'border-slate-200 bg-slate-50'
              }`}
              value={formData.namaInstansi}
              onChange={(e) => handleFieldChange('namaInstansi', e.target.value)}
            />
            {errors.namaInstansi && <p className="text-[10px] text-red-500 font-medium">{errors.namaInstansi}</p>}
          </div>

          {/* Row 3: Alamat / Detail Kop Surat */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-500 uppercase tracking-wider block">Alamat / Kontak Kop Surat</label>
            <textarea
              rows={2}
              placeholder="Contoh: Jl. Budi Utomo No.7, Sawah Besar, Jakarta | Telp: (021) 3813630 | www.smkn1jakarta.sch.id"
              className="w-full px-4 py-2.5 border border-slate-200 bg-slate-50 rounded-[14px] text-sm focus:ring-2 focus:ring-[#0F4C81] focus:border-transparent transition-all outline-none resize-none"
              value={formData.kopSurat}
              onChange={(e) => handleFieldChange('kopSurat', e.target.value)}
            />
          </div>

          {/* Row 4: Drag & Drop Logo Instansi */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-500 uppercase tracking-wider block">Logo Instansi</label>
            <div
              onDragOver={(e) => { e.preventDefault(); setDragActiveLogo(true); }}
              onDragLeave={() => setDragActiveLogo(false)}
              onDrop={(e) => {
                e.preventDefault();
                setDragActiveLogo(false);
                if (e.dataTransfer.files?.[0]) handleImageUpload('logoInstansi', e.dataTransfer.files[0]);
              }}
              className={`border-2 border-dashed rounded-[14px] p-4 text-center transition-all relative flex flex-col items-center justify-center gap-1.5 cursor-pointer ${
                dragActiveLogo ? 'border-[#0F4C81] bg-[#0F4C81]/5' : 'border-slate-200 bg-slate-50 hover:bg-slate-100/50'
              }`}
              onClick={() => {
                const el = document.getElementById('logo-file-input');
                if (el) el.click();
              }}
            >
              <input
                id="logo-file-input"
                type="file"
                className="hidden"
                accept="image/*"
                onChange={(e) => {
                  if (e.target.files?.[0]) handleImageUpload('logoInstansi', e.target.files[0]);
                }}
              />
              <Upload size={18} className="text-slate-400" />
              <div className="text-[11px] text-slate-500">
                <strong>Klik untuk upload</strong> atau drag & drop file logo instansi (PNG / SVG)
              </div>
              {formData.logoInstansi && (
                <div className="flex items-center gap-2 mt-1 bg-white p-1 px-3 rounded-full border border-slate-200 shadow-sm">
                  <span className="text-[9px] font-bold text-green-700 flex items-center gap-0.5">
                    <Check size={10} /> Logo Siap
                  </span>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleFieldChange('logoInstansi', '');
                    }}
                    className="text-[9px] text-red-500 font-bold hover:underline"
                  >
                    Hapus
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Row 5: Penerima (Kepada) */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-500 uppercase tracking-wider block">Penerima Surat (Kepada Yth.) <span className="text-red-500">*</span></label>
            <textarea
              rows={2}
              placeholder="Contoh: Yth. Kepala Cabang PT Maju Jaya&#10;Jl. Sudirman No. 12, Jakarta"
              className={`w-full px-4 py-2.5 border rounded-[14px] text-sm focus:ring-2 focus:ring-[#0F4C81] focus:border-transparent transition-all outline-none resize-none ${
                errors.kepada ? 'border-red-500 bg-red-50/30' : 'border-slate-200 bg-slate-50'
              }`}
              value={formData.kepada}
              onChange={(e) => handleFieldChange('kepada', e.target.value)}
            />
            {errors.kepada && <p className="text-[10px] text-red-500 font-medium">{errors.kepada}</p>}
          </div>

          {/* Row 6: Isi Surat (Rich Text Editor) */}
          <div className="space-y-1.5">
            <div className="flex justify-between items-center">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider block">Isi Surat <span className="text-red-500">*</span></label>
              <span className="text-[10px] font-mono text-slate-400 bg-slate-100 px-2 py-0.5 rounded">{charCount} Karakter</span>
            </div>

            {/* Custom Rich Text Toolbar */}
            <div className="border border-slate-200 rounded-[14px] overflow-hidden bg-white">
              <div className="flex flex-wrap items-center gap-1 p-2 bg-slate-50 border-b border-slate-200">
                <button
                  type="button"
                  onClick={() => executeEditorCommand('bold')}
                  className="p-1.5 text-slate-600 hover:bg-slate-200 rounded-lg transition-colors"
                  title="Tebal (Bold)"
                >
                  <Bold size={14} />
                </button>
                <button
                  type="button"
                  onClick={() => executeEditorCommand('italic')}
                  className="p-1.5 text-slate-600 hover:bg-slate-200 rounded-lg transition-colors"
                  title="Miring (Italic)"
                >
                  <Italic size={14} />
                </button>
                <button
                  type="button"
                  onClick={() => executeEditorCommand('underline')}
                  className="p-1.5 text-slate-600 hover:bg-slate-200 rounded-lg transition-colors"
                  title="Garis Bawah (Underline)"
                >
                  <Underline size={14} />
                </button>
                <div className="w-px h-4 bg-slate-300 mx-1" />
                <button
                  type="button"
                  onClick={() => executeEditorCommand('insertUnorderedList')}
                  className="p-1.5 text-slate-600 hover:bg-slate-200 rounded-lg transition-colors"
                  title="Daftar Bullet (Unordered List)"
                >
                  <List size={14} />
                </button>
                <button
                  type="button"
                  onClick={() => executeEditorCommand('insertOrderedList')}
                  className="p-1.5 text-slate-600 hover:bg-slate-200 rounded-lg transition-colors"
                  title="Daftar Angka (Ordered List)"
                >
                  <ListOrdered size={14} />
                </button>
              </div>

              {/* Editable area */}
              <div
                ref={editorRef}
                contentEditable
                onInput={(e) => {
                  handleFieldChange('isiSurat', e.currentTarget.innerHTML);
                }}
                className={`p-4 min-h-[150px] max-h-[250px] overflow-y-auto text-sm outline-none focus:bg-white transition-all bg-slate-50/20 leading-relaxed ${
                  errors.isiSurat ? 'border-red-500' : ''
                }`}
                placeholder="Ketikkan isi surat di sini..."
                style={{ fontFamily: "'Times New Roman', Times, serif" }}
              />
            </div>
            {errors.isiSurat && <p className="text-[10px] text-red-500 font-medium">{errors.isiSurat}</p>}
          </div>

          {/* Row 7: Tanda Tangan */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider block">Nama Pimpinan <span className="text-red-500">*</span></label>
              <input
                type="text"
                placeholder="Contoh: Drs. H. Ahmad Fauzi, M.Pd."
                className={`w-full px-4 py-2.5 border rounded-[14px] text-sm focus:ring-2 focus:ring-[#0F4C81] focus:border-transparent transition-all outline-none ${
                  errors.namaPimpinan ? 'border-red-500 bg-red-50/30' : 'border-slate-200 bg-slate-50'
                }`}
                value={formData.namaPimpinan}
                onChange={(e) => handleFieldChange('namaPimpinan', e.target.value)}
              />
              {errors.namaPimpinan && <p className="text-[10px] text-red-500 font-medium">{errors.namaPimpinan}</p>}
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider block">Jabatan <span className="text-red-500">*</span></label>
              <input
                type="text"
                placeholder="Contoh: Kepala Sekolah"
                className={`w-full px-4 py-2.5 border rounded-[14px] text-sm focus:ring-2 focus:ring-[#0F4C81] focus:border-transparent transition-all outline-none ${
                  errors.jabatan ? 'border-red-500 bg-red-50/30' : 'border-slate-200 bg-slate-50'
                }`}
                value={formData.jabatan}
                onChange={(e) => handleFieldChange('jabatan', e.target.value)}
              />
              {errors.jabatan && <p className="text-[10px] text-red-500 font-medium">{errors.jabatan}</p>}
            </div>
          </div>

          {/* Row 8: Drag & Drop Tanda Tangan (PNG Transparan) */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-500 uppercase tracking-wider block">Tanda Tangan Pimpinan (PNG Transparan)</label>
            <div
              onDragOver={(e) => { e.preventDefault(); setDragActiveTtd(true); }}
              onDragLeave={() => setDragActiveTtd(false)}
              onDrop={(e) => {
                e.preventDefault();
                setDragActiveTtd(false);
                if (e.dataTransfer.files?.[0]) handleImageUpload('gambarTtd', e.dataTransfer.files[0]);
              }}
              className={`border-2 border-dashed rounded-[14px] p-4 text-center transition-all relative flex flex-col items-center justify-center gap-1.5 cursor-pointer ${
                dragActiveTtd ? 'border-[#0F4C81] bg-[#0F4C81]/5' : 'border-slate-200 bg-slate-50 hover:bg-slate-100/50'
              }`}
              onClick={() => {
                const el = document.getElementById('ttd-file-input');
                if (el) el.click();
              }}
            >
              <input
                id="ttd-file-input"
                type="file"
                className="hidden"
                accept="image/*"
                onChange={(e) => {
                  if (e.target.files?.[0]) handleImageUpload('gambarTtd', e.target.files[0]);
                }}
              />
              <Upload size={18} className="text-slate-400" />
              <div className="text-[11px] text-slate-500">
                <strong>Klik untuk upload</strong> atau drag & drop tanda tangan PNG transparan
              </div>
              {formData.gambarTtd && (
                <div className="flex items-center gap-2 mt-1 bg-white p-1 px-3 rounded-full border border-slate-200 shadow-sm">
                  <span className="text-[9px] font-bold text-green-700 flex items-center gap-0.5">
                    <Check size={10} /> TTD Siap
                  </span>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleFieldChange('gambarTtd', '');
                    }}
                    className="text-[9px] text-red-500 font-bold hover:underline"
                  >
                    Hapus
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Row 9: Tembusan */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-500 uppercase tracking-wider block">Tembusan (Tiap Pihak per Baris Baru)</label>
            <textarea
              rows={3}
              placeholder="Contoh:&#10;1. Komite Sekolah SMK&#10;2. Ketua Program Keahlian MPLB&#10;3. Arsip"
              className="w-full px-4 py-2.5 border border-slate-200 bg-slate-50 rounded-[14px] text-sm focus:ring-2 focus:ring-[#0F4C81] focus:border-transparent transition-all outline-none resize-none"
              value={formData.tembusan}
              onChange={(e) => handleFieldChange('tembusan', e.target.value)}
            />
          </div>

          {/* Bottom Form Actions - Editorial Style rounded-[14px] */}
          <div className="grid grid-cols-2 gap-3 pt-3">
            <button
              onClick={handleReset}
              className="flex items-center justify-center space-x-2 py-3 bg-white border border-slate-200 rounded-[14px] text-xs font-bold text-slate-600 hover:bg-slate-50 transition-colors"
            >
              <Trash2 size={14} />
              <span>RESET FORM</span>
            </button>
            <button
              onClick={handleGenerateSurat}
              className="flex items-center justify-center space-x-2 py-3 bg-[#0F4C81] text-white rounded-[14px] text-xs font-bold shadow-md hover:shadow-lg transition-all hover:scale-[1.01]"
            >
              <Sparkles size={14} className="text-[#FFC857] animate-pulse" />
              <span>GENERATE SURAT</span>
            </button>
          </div>

          {/* Quick PDF & Print Actions inside the Form for high accessibility */}
          <div className="grid grid-cols-2 gap-3 pt-1 border-t border-slate-100 mt-2">
            <button
              onClick={handleDownloadPDF}
              className="flex items-center justify-center space-x-2 py-3 bg-green-600 hover:bg-green-700 text-white rounded-[14px] text-xs font-bold shadow-sm transition-all hover:scale-[1.01]"
              title="Ekspor ke PDF HD"
            >
              <Download size={14} />
              <span>UNDUH PDF</span>
            </button>
            <button
              onClick={handlePrint}
              className="flex items-center justify-center space-x-2 py-3 bg-[#FFC857] hover:bg-[#f3bc47] text-[#0F4C81] rounded-[14px] text-xs font-bold shadow-sm transition-all hover:scale-[1.01]"
              title="Cetak Surat dengan Printer / PDF"
            >
              <Printer size={14} />
              <span>CETAK SURAT</span>
            </button>
          </div>

        </div>

      </div>

      {/* RIGHT COLUMN: Live Preview Panel (7 Cols) */}
      <div className="xl:col-span-7 flex flex-col gap-4">
        
        {/* Controls Panel */}
        <div className="bg-white p-4 rounded-2xl shadow-lg border border-gray-100 flex flex-wrap gap-3 justify-between items-center print:hidden">
          
          {/* Zoom and Appearance Controls */}
          <div className="flex items-center gap-1">
            <button
              onClick={() => setZoomLevel(prev => Math.max(50, prev - 10))}
              className="p-2 hover:bg-gray-100 text-gray-600 rounded-lg transition-colors"
              title="Perkecil Preview"
            >
              <ZoomOut size={16} />
            </button>
            <span className="text-xs font-mono font-bold text-gray-500 w-12 text-center">{zoomLevel}%</span>
            <button
              onClick={() => setZoomLevel(prev => Math.min(150, prev + 10))}
              className="p-2 hover:bg-gray-100 text-gray-600 rounded-lg transition-colors"
              title="Perbesar Preview"
            >
              <ZoomIn size={16} />
            </button>
            
            <div className="w-px h-5 bg-gray-200 mx-1" />
            
            <button
              onClick={() => setPreviewDarkMode(!previewDarkMode)}
              className={`p-2 rounded-lg transition-colors ${
                previewDarkMode ? 'bg-amber-100 text-amber-800' : 'hover:bg-gray-100 text-gray-600'
              }`}
              title={previewDarkMode ? 'Aktifkan Mode Kertas Terang' : 'Aktifkan Mode Gelap Istirahat Mata'}
            >
              {previewDarkMode ? <Sun size={16} /> : <Moon size={16} />}
            </button>
          </div>

          {/* Major Document Operations */}
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setIsFullscreen(true)}
              className="px-3 py-2 border border-slate-200 hover:bg-slate-50 text-slate-600 rounded-xl text-xs font-semibold flex items-center gap-1 transition-all"
              title="Lihat Pratinjau Full Screen"
            >
              <Maximize2 size={14} />
              Full Screen
            </button>
            <button
              onClick={handlePrint}
              className="px-3.5 py-2 bg-[#FFC857] hover:bg-[#f3bc47] text-[#0F4C81] rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm hover:scale-[1.02]"
              title="Cetak Surat dengan CSS Print khusus"
            >
              <Printer size={14} className="stroke-[2.5px]" />
              CETAK / PRINT
            </button>
            <button
              onClick={handleSendEmail}
              className="px-3 py-2 bg-amber-50 text-amber-800 hover:bg-[#FFC857]/20 rounded-xl text-xs font-semibold flex items-center gap-1 transition-all"
              title="Kirim via EmailJS"
            >
              <Mail size={14} />
              Kirim Email
            </button>
            <button
              onClick={handleDownloadPDF}
              className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-md hover:scale-[1.02]"
              title="Ekspor ke PDF HD"
            >
              <Download size={14} className="stroke-[2.5px]" />
              UNDUH PDF
            </button>
          </div>
        </div>

        {/* Outer Canvas Stage */}
        <div className="bg-slate-200/90 dark:bg-slate-900/40 p-6 rounded-2xl shadow-inner border border-slate-300/60 flex justify-center items-start overflow-auto max-h-[850px] print:p-0 print:bg-white print:border-none print:shadow-none">
          
          {/* Authentic Document A4 Sheet - Editorial Aesthetic Theme */}
          <div 
            id="letter-preview-card"
            ref={previewRef}
            style={{ 
              transform: `scale(${zoomLevel / 100})`,
              transformOrigin: 'top center',
              fontFamily: "'Times New Roman', Times, serif"
            }}
            className={`w-[794px] min-h-[1123px] bg-white p-12 md:p-16 shadow-2xl transition-all text-slate-900 border border-slate-300 relative leading-relaxed text-justify text-sm rounded-none print:shadow-none print:border-none print:m-0 print:p-0 ${
              previewDarkMode ? 'invert bg-slate-100' : ''
            }`}
          >
            {/* Letter Watermark */}
            <div className="absolute inset-0 flex items-center justify-center opacity-[0.03] pointer-events-none select-none print:hidden">
              <svg viewBox="0 0 24 24" className="w-80 h-80 fill-slate-900"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>
            </div>

            {/* Header / Kop Surat - Professional Editorial double border */}
            <div className="flex items-center gap-6 pb-4 border-b-4 border-double border-slate-900 mb-6 z-10 relative">
              {formData.logoInstansi && (
                <img 
                  src={formData.logoInstansi} 
                  alt="Logo Instansi" 
                  className="w-16 h-16 object-contain shrink-0" 
                  referrerPolicy="no-referrer"
                />
              )}
              <div className="text-center flex-1">
                <h1 className="text-base md:text-lg font-bold uppercase tracking-wide leading-tight whitespace-pre-line text-slate-900">
                  {formData.namaInstansi || 'SMK NEGERI / SWASTA ADMINISTRASI'}
                </h1>
                <p className="text-[10px] md:text-xs text-slate-600 mt-1 whitespace-pre-line font-serif italic">
                  {formData.kopSurat || 'Alamat Lengkap Instansi, Nomor Telepon, Fax, dan Surel Resmi'}
                </p>
              </div>
            </div>

            {/* Nomor, Lampiran, Hal & Tanggal Row */}
            <div className="flex justify-between items-start mb-6 z-10 relative">
              <div className="space-y-0.5 text-slate-800 text-[13px]">
                <div><strong>Nomor:</strong> {formData.nomorSurat || '.../SMK/.../2026'}</div>
                <div><strong>Lampiran:</strong> -</div>
                <div><strong>Hal:</strong> Permohonan / Undangan</div>
              </div>
              <div className="text-right text-slate-800 text-[13px]">
                {formData.tanggalSurat ? (
                  new Date(formData.tanggalSurat).toLocaleDateString('id-ID', {
                    day: 'numeric',
                    month: 'long',
                    year: 'numeric'
                  })
                ) : '(Tanggal Surat)'}
              </div>
            </div>

            {/* Kepada Yth. */}
            <div className="mb-6 space-y-1 z-10 relative">
              <p className="text-slate-800 text-[13px]"><strong>Kepada Yth.</strong></p>
              <p className="whitespace-pre-line text-slate-850 leading-relaxed font-serif pl-0 text-[13px]">
                {formData.kepada || 'Nama Jabatan / Penerima\ndi Tempat'}
              </p>
            </div>

            {/* Isi Surat */}
            <div className="mb-10 text-justify leading-relaxed text-slate-900 font-serif text-[13px] z-10 relative">
              {formData.isiSurat ? (
                <div 
                  dangerouslySetInnerHTML={{ __html: formData.isiSurat }} 
                  className="space-y-3 prose max-w-none text-slate-900"
                />
              ) : (
                <div className="py-12 text-center text-slate-400 italic space-y-2 border border-dashed border-slate-200 rounded-xl bg-slate-50/50 print:border-none">
                  <p>Isi surat masih kosong.</p>
                  <p className="text-[10px]">Silakan masukkan teks pada formulir di sebelah kiri untuk melihat pembaruan otomatis.</p>
                </div>
              )}
            </div>

            {/* TTD Pimpinan Section (Aligned to the right) */}
            <div className="flex justify-end mb-8 z-10 relative">
              <div className="w-64 text-center space-y-1 text-slate-800 text-[13px]">
                <p className="mb-12"><strong>{formData.jabatan || 'Kepala Sekolah'}</strong>,</p>
                
                {formData.gambarTtd ? (
                  <div className="relative h-16 my-[-30px] flex justify-center items-center">
                    <img 
                      src={formData.gambarTtd} 
                      alt="Tanda Tangan" 
                      className="max-h-16 object-contain pointer-events-none"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                ) : (
                  <div className="h-10 border border-dashed border-slate-200 flex items-center justify-center text-slate-300 text-[10px] uppercase tracking-wider print:hidden">
                    Tanda Tangan Pimpinan
                  </div>
                )}
                
                <p className="pt-2 font-bold text-slate-900 underline">{formData.namaPimpinan || 'Nama Pimpinan Lengkap'}</p>
                <p className="text-[10px] text-gray-500 font-mono">NIP. 19750812 200003 1 002</p>
              </div>
            </div>

            {/* Tembusan Section */}
            {formData.tembusan && (
              <div className="border-t border-slate-200 pt-3 text-[12px] text-slate-600 font-serif space-y-1 z-10 relative">
                <strong>Tembusan:</strong>
                <p className="whitespace-pre-line leading-relaxed pl-1">
                  {formData.tembusan}
                </p>
              </div>
            )}

            {/* High-Fidelity Pedagogical Grid Background Overlay for learning alignment */}
            <div className="absolute top-2 right-2 text-[8px] bg-blue-100 text-[#0F4C81] p-1 px-1.5 rounded uppercase font-bold tracking-widest font-sans opacity-40 select-none print:hidden">
              SIMULASI MANDIRI
            </div>
          </div>

        </div>

      </div>

      {/* FULL SCREEN PREVIEW MODAL */}
      <AnimatePresence>
        {isFullscreen && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex flex-col justify-between p-6 overflow-auto">
            
            {/* Modal Top Actions Bar */}
            <div className="flex justify-between items-center text-white pb-4 border-b border-white/10">
              <h4 className="font-bold text-base flex items-center gap-2">
                <FileText className="text-[#FFC857]" />
                Pratinjau Full Screen - Smart Letter Generator
              </h4>
              <button
                onClick={() => setIsFullscreen(false)}
                className="p-2 bg-white/10 hover:bg-white/20 text-white rounded-full transition-colors flex items-center gap-1.5 text-xs font-semibold"
              >
                <Minimize2 size={16} />
                Tutup Preview
              </button>
            </div>

            {/* Inner Scale Scroll Stage */}
            <div className="flex-1 flex justify-center items-center py-6">
              <div className="w-[794px] bg-white p-16 shadow-2xl text-black border border-gray-200 overflow-auto scale-90 md:scale-100 transform Origin-center max-h-[90vh]">
                
                {/* Header / Kop Surat */}
                <div className="flex items-center gap-4 border-b-[3px] border-black pb-2 mb-1.5">
                  {formData.logoInstansi && (
                    <img src={formData.logoInstansi} alt="Logo" className="w-18 h-18 object-contain shrink-0" referrerPolicy="no-referrer" />
                  )}
                  <div className="text-center flex-1">
                    <h1 className="text-base font-bold uppercase tracking-wide leading-tight whitespace-pre-line">{formData.namaInstansi || 'SMK NEGERI ADMINISTRASI'}</h1>
                    <p className="text-[10px] text-gray-600 mt-1 whitespace-pre-line font-serif italic">{formData.kopSurat}</p>
                  </div>
                </div>
                
                <div className="border-t border-black mb-6" />

                <div className="flex justify-between items-start mb-6 text-xs">
                  <div>
                    <div><strong>Nomor:</strong> {formData.nomorSurat}</div>
                    <div><strong>Lampiran:</strong> -</div>
                    <div><strong>Hal:</strong> Permohonan / Undangan</div>
                  </div>
                  <div>
                    {formData.tanggalSurat ? new Date(formData.tanggalSurat).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' }) : '-'}
                  </div>
                </div>

                <div className="mb-6 text-xs">
                  <p><strong>Kepada Yth.</strong></p>
                  <p className="whitespace-pre-line text-gray-800 leading-relaxed font-serif">{formData.kepada}</p>
                </div>

                <div className="mb-10 text-justify text-xs leading-relaxed font-serif" dangerouslySetInnerHTML={{ __html: formData.isiSurat }} />

                <div className="flex justify-end mb-8 text-xs">
                  <div className="w-64 text-center">
                    <p className="mb-12"><strong>{formData.jabatan}</strong>,</p>
                    {formData.gambarTtd && (
                      <div className="relative h-12 my-[-25px] flex justify-center items-center">
                        <img src={formData.gambarTtd} alt="TTD" className="max-h-12 object-contain" referrerPolicy="no-referrer" />
                      </div>
                    )}
                    <p className="pt-2 font-bold text-gray-900 underline">{formData.namaPimpinan}</p>
                    <p className="text-[10px] text-gray-500 font-mono">NIP. 19750812 200003 1 002</p>
                  </div>
                </div>

                {formData.tembusan && (
                  <div className="border-t border-gray-200 pt-3 text-xs text-gray-600 font-serif">
                    <strong>Tembusan:</strong>
                    <p className="whitespace-pre-line leading-relaxed mt-1">{formData.tembusan}</p>
                  </div>
                )}
              </div>
            </div>

            <p className="text-center text-white/50 text-xs mt-4">Tekan ESC atau Klik Tutup di pojok kanan atas untuk keluar.</p>
          </div>
        )}
      </AnimatePresence>

      {/* EMAILJS SETTINGS DRAWER/MODAL */}
      <AnimatePresence>
        {isSettingsOpen && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-2xl shadow-2xl p-6 max-w-md w-full border border-gray-100 space-y-4"
            >
              <div className="flex justify-between items-center border-b border-gray-100 pb-3">
                <h4 className="font-bold text-gray-800 text-sm flex items-center gap-2">
                  <Settings className="text-[#0F4C81]" size={18} />
                  Kunci Konfigurasi EmailJS
                </h4>
                <button
                  onClick={() => setIsSettingsOpen(false)}
                  className="text-gray-400 hover:text-gray-600 font-bold"
                >
                  ✕
                </button>
              </div>

              <div className="bg-blue-50/50 p-4 rounded-xl border border-blue-100 text-xs text-blue-800 leading-relaxed space-y-1.5">
                <p className="font-bold">💡 Informasi Pembelajaran:</p>
                <p>EmailJS membantu siswa berlatih mengirim email formal otomatis langsung dari aplikasi web. Isi kunci yang Anda dapatkan dari dasbor pribadi EmailJS Anda.</p>
              </div>

              <div className="space-y-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-gray-700 block">Service ID</label>
                  <input
                    type="text"
                    placeholder="Contoh: service_abc123"
                    className="w-full px-3 py-2 border border-gray-200 bg-gray-50/50 rounded-xl text-xs outline-none focus:ring-2 focus:ring-[#0F4C81] transition-all"
                    value={emailConfig.serviceId}
                    onChange={(e) => setEmailConfig({ ...emailConfig, serviceId: e.target.value })}
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-gray-700 block">Template ID</label>
                  <input
                    type="text"
                    placeholder="Contoh: template_xyz456"
                    className="w-full px-3 py-2 border border-gray-200 bg-gray-50/50 rounded-xl text-xs outline-none focus:ring-2 focus:ring-[#0F4C81] transition-all"
                    value={emailConfig.templateId}
                    onChange={(e) => setEmailConfig({ ...emailConfig, templateId: e.target.value })}
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-gray-700 block">Public Key</label>
                  <input
                    type="text"
                    placeholder="Contoh: user_L9F68B1..."
                    className="w-full px-3 py-2 border border-gray-200 bg-gray-50/50 rounded-xl text-xs outline-none focus:ring-2 focus:ring-[#0F4C81] transition-all"
                    value={emailConfig.publicKey}
                    onChange={(e) => setEmailConfig({ ...emailConfig, publicKey: e.target.value })}
                  />
                </div>
              </div>

              <div className="flex gap-2 pt-3 justify-end text-xs">
                <button
                  onClick={() => setIsSettingsOpen(false)}
                  className="px-4 py-2 bg-gray-100 hover:bg-gray-200 font-semibold rounded-xl text-gray-600 transition-colors"
                >
                  Batal
                </button>
                <button
                  onClick={handleSaveEmailConfig}
                  className="px-4 py-2 bg-[#0F4C81] hover:bg-[#0C3C66] text-white font-semibold rounded-xl transition-all shadow-md"
                >
                  Simpan Pengaturan
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* CONFIRMATION EMAIL DIALOG POPUP */}
      <AnimatePresence>
        {isEmailModalOpen && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-2xl shadow-2xl p-6 max-w-lg w-full border border-gray-100 space-y-4"
            >
              <div className="flex justify-between items-center border-b border-gray-100 pb-3">
                <h4 className="font-bold text-gray-800 text-sm flex items-center gap-2">
                  <Mail className="text-[#FFC857]" size={18} />
                  Kirim Surat via Email (EmailJS)
                </h4>
                <button
                  onClick={() => setIsEmailModalOpen(false)}
                  className="text-gray-400 hover:text-gray-600 font-bold"
                >
                  ✕
                </button>
              </div>

              <form onSubmit={handleConfirmSendEmail} className="space-y-4 text-xs">
                
                <div className="space-y-1.5">
                  <label className="font-bold text-gray-700 block">Email Penerima / Tujuan <span className="text-red-500">*</span></label>
                  <input
                    type="email"
                    required
                    placeholder="Contoh: hrd@perusahaan.com atau mitra@smk.sch.id"
                    className="w-full px-3 py-2.5 border border-gray-200 bg-gray-50/50 rounded-xl outline-none focus:ring-2 focus:ring-[#0F4C81] transition-all"
                    value={emailForm.to_email}
                    onChange={(e) => setEmailForm({ ...emailForm, to_email: e.target.value })}
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="font-bold text-gray-700 block">Subjek Email</label>
                  <input
                    type="text"
                    required
                    className="w-full px-3 py-2.5 border border-gray-200 bg-gray-50/50 rounded-xl outline-none focus:ring-2 focus:ring-[#0F4C81] transition-all"
                    value={emailForm.subject}
                    onChange={(e) => setEmailForm({ ...emailForm, subject: e.target.value })}
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="font-bold text-gray-700 block">Pesan Pendamping</label>
                  <textarea
                    rows={4}
                    className="w-full px-3 py-2 border border-gray-200 bg-gray-50/50 rounded-xl outline-none focus:ring-2 focus:ring-[#0F4C81] transition-all resize-none"
                    value={emailForm.message}
                    onChange={(e) => setEmailForm({ ...emailForm, message: e.target.value })}
                  />
                </div>

                <div className="bg-amber-50 p-3 rounded-xl border border-amber-100 text-[11px] text-amber-800 leading-relaxed">
                  ⚠️ <strong>Catatan Lampiran:</strong> Generator akan merender, mengompres, dan melampirkan file <strong>Surat_{formData.nomorSurat.replace(/[\/\\?%*:|"<>\s]/g, '_')}.pdf</strong> secara otomatis ke email ini.
                </div>

                <div className="flex gap-2 pt-3 justify-end">
                  <button
                    type="button"
                    disabled={isSendingEmail}
                    onClick={() => setIsEmailModalOpen(false)}
                    className="px-4 py-2 bg-gray-100 hover:bg-gray-200 font-semibold rounded-xl text-gray-600 transition-colors"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    disabled={isSendingEmail}
                    className="px-5 py-2 bg-amber-500 hover:bg-amber-600 disabled:bg-amber-300 text-white font-bold rounded-xl transition-all shadow-md flex items-center gap-1.5"
                  >
                    {isSendingEmail ? (
                      <>
                        <RefreshCw size={14} className="animate-spin" />
                        Sedang Mengirim...
                      </>
                    ) : (
                      <>
                        <Mail size={14} />
                        Kirim Sekarang
                      </>
                    )}
                  </button>
                </div>

              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
