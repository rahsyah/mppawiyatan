/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import emailjs from '@emailjs/browser';
import { EmailJSConfig } from '../types';

/**
 * Sends an email using EmailJS.
 * Users can supply their custom keys, or we can fallback to helpful logging / instructions.
 */
export async function sendLetterEmail(
  config: EmailJSConfig,
  params: {
    to_email: string;
    subject: string;
    message: string;
    nomorSurat: string;
    namaInstansi: string;
    namaPimpinan: string;
    letterHtmlContent: string;
    pdfDataUrl?: string; // Optional PDF attachment as Data URL
  }
): Promise<void> {
  const { serviceId, templateId, publicKey } = config;

  if (!serviceId || !templateId || !publicKey) {
    throw new Error('Konfigurasi EmailJS belum lengkap. Silakan isi Service ID, Template ID, dan Public Key di panel pengaturan.');
  }

  // Pre-process attachment if provided (EmailJS supports Base64 attachments in templates
  // if configured as a template variable e.g. {{content_base64}})
  const templateParams = {
    to_email: params.to_email,
    to_name: params.to_email.split('@')[0],
    subject: params.subject,
    message: params.message,
    nomor_surat: params.nomorSurat,
    nama_instansi: params.namaInstansi,
    nama_pimpinan: params.namaPimpinan,
    letter_content: params.letterHtmlContent.replace(/<[^>]*>/g, ''), // Strip tags for text email
    content_base64: params.pdfDataUrl || '', // Base64 attachment variable
  };

  try {
    const response = await emailjs.send(serviceId, templateId, templateParams, publicKey);
    if (response.status !== 200) {
      throw new Error(`EmailJS Gagal: ${response.text}`);
    }
  } catch (error: any) {
    console.error('EmailJS Error:', error);
    throw new Error(error.message || 'Gagal mengirim email. Periksa kembali konfigurasi kunci EmailJS Anda.');
  }
}
