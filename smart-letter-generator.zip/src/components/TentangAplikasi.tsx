/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Award, Code, CheckCircle, Users, GraduationCap, MapPin } from 'lucide-react';

export default function TentangAplikasi() {
  return (
    <div className="space-y-8" id="tentang-aplikasi-root">
      {/* Hero Header */}
      <div className="bg-white p-8 md:p-12 rounded-2xl shadow-lg border border-gray-100 flex flex-col md:flex-row items-center gap-8 relative overflow-hidden">
        {/* Abstract Gold decorative background */}
        <div className="absolute top-0 right-0 w-48 h-48 bg-[#FFC857]/10 rounded-full blur-3xl -mr-16 -mt-16" />
        <div className="absolute bottom-0 left-0 w-32 h-32 bg-[#0F4C81]/5 rounded-full blur-2xl -ml-8 -mb-8" />

        <div className="w-24 h-24 md:w-32 md:h-32 bg-gradient-to-tr from-[#0F4C81] to-blue-500 rounded-2xl flex items-center justify-center text-white shadow-xl flex-shrink-0">
          <GraduationCap size={48} className="md:size-60" />
        </div>
        
        <div className="text-center md:text-left space-y-3 flex-1">
          <div className="inline-block bg-[#0F4C81]/10 text-[#0F4C81] text-xs px-3 py-1.5 rounded-full font-bold">
            Aplikasi Pendidikan Vokasi v1.0
          </div>
          <h2 className="text-2xl md:text-3xl font-bold text-gray-800 font-sans tracking-tight">
            Smart Letter Generator
          </h2>
          <p className="text-gray-500 text-sm md:text-base leading-relaxed max-w-2xl">
            Aplikasi simulator dan generator surat dinas otomatis yang dirancang khusus sebagai media pembelajaran interaktif bagi siswa Sekolah Menengah Kejuruan (SMK) Bidang Keahlian Bisnis dan Manajemen, khususnya Program Keahlian <strong>Manajemen Perkantoran dan Layanan Bisnis (MPLB)</strong>.
          </p>
        </div>
      </div>

      {/* Grid Features */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-2xl shadow-md border border-gray-50 space-y-4">
          <div className="w-12 h-12 bg-blue-50 text-[#0F4C81] rounded-xl flex items-center justify-center">
            <Award size={24} />
          </div>
          <h3 className="font-bold text-gray-800 text-base">Standar Industri</h3>
          <p className="text-gray-500 text-xs leading-relaxed">
            Format dan tata letak surat hasil generator disesuaikan dengan Pedoman Tata Naskah Dinas Kementerian Pendidikan, Kebudayaan, Riset, dan Teknologi untuk menjamin kesesuaian administrasi di dunia kerja nyata (DUDI).
          </p>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-md border border-gray-50 space-y-4">
          <div className="w-12 h-12 bg-amber-50 text-[#FFC857] rounded-xl flex items-center justify-center">
            <Users size={24} />
          </div>
          <h3 className="font-bold text-gray-800 text-base">Media Pembelajaran Mandiri</h3>
          <p className="text-gray-500 text-xs leading-relaxed">
            Dilengkapi fitur interaktif, panduan langkah demi langkah, visualisasi kesalahan penulisan, dan live preview yang membantu siswa berlatih membuat korespondensi secara tepat waktu.
          </p>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-md border border-gray-50 space-y-4">
          <div className="w-12 h-12 bg-green-50 text-green-600 rounded-xl flex items-center justify-center">
            <Code size={24} />
          </div>
          <h3 className="font-bold text-gray-800 text-base">Teknologi Modern</h3>
          <p className="text-gray-500 text-xs leading-relaxed">
            Didukung rendering berkecepatan tinggi, auto-save local storage, konversi PDF klien definisi tinggi (HD), dan konektivitas email langsung melalui modul EmailJS tanpa server (serverless).
          </p>
        </div>
      </div>

      {/* Developer & Credits Section */}
      <div className="bg-white p-8 rounded-2xl shadow-md border border-gray-100 grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
        <div className="space-y-4">
          <h4 className="font-bold text-gray-800 text-lg flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#FFC857]" />
            Informasi Pengembang
          </h4>
          <p className="text-gray-500 text-sm leading-relaxed">
            Aplikasi ini dikembangkan untuk memodernisasi pembelajaran administrasi perkantoran, meminimalkan penggunaan kertas (eco-friendly), serta melatih literasi digital siswa SMK di era Revolusi Industri 4.0.
          </p>
          
          <div className="space-y-2.5 text-xs text-gray-600 font-mono">
            <div className="flex items-center gap-2">
              <span className="font-bold text-gray-400 w-24">Aplikasi:</span>
              <span>Smart Letter Generator v1.0</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-gray-400 w-24">Kurikulum:</span>
              <span>Merdeka Belajar / K13 Revisi</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-gray-400 w-24">Saran Sasaran:</span>
              <span>SMK Jurusan Manajemen Perkantoran</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-gray-400 w-24">Kategori:</span>
              <span>Media Pembelajaran Digital Interaktif</span>
            </div>
          </div>
        </div>

        <div className="bg-gray-50 p-6 rounded-xl border border-gray-200 space-y-4 flex flex-col justify-between">
          <h5 className="font-bold text-[#0F4C81] text-sm">Didukung Oleh:</h5>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center border border-gray-200 shadow-sm text-[#0F4C81] font-bold text-lg font-sans">
              MP
            </div>
            <div>
              <h6 className="font-bold text-gray-800 text-xs">Jurusan Manajemen Perkantoran</h6>
              <p className="text-gray-400 text-[10px]">Pendidikan Menengah Kejuruan (SMK)</p>
            </div>
          </div>
          <div className="flex items-center gap-2 text-xs text-gray-500">
            <MapPin size={14} className="text-[#FFC857]" />
            <span>Indonesia (NKRI) • Berorientasi Masa Depan</span>
          </div>
        </div>
      </div>

      {/* Target Competencies */}
      <div className="bg-[#0F4C81]/5 p-6 rounded-2xl border border-[#0F4C81]/15 space-y-4">
        <h4 className="font-bold text-[#0F4C81] text-base">🎯 Kompetensi Dasar & Keterampilan yang Ditargetkan:</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs text-gray-700">
          <div className="flex items-start gap-2">
            <CheckCircle size={14} className="text-green-500 mt-0.5 flex-shrink-0" />
            <span>Menerapkan prosedur pembuatan surat dinas/pemerintah resmi secara terkomputerisasi.</span>
          </div>
          <div className="flex items-start gap-2">
            <CheckCircle size={14} className="text-green-500 mt-0.5 flex-shrink-0" />
            <span>Mengoperasikan aplikasi administrasi perkantoran modern yang berbasis teknologi web.</span>
          </div>
          <div className="flex items-start gap-2">
            <CheckCircle size={14} className="text-green-500 mt-0.5 flex-shrink-0" />
            <span>Melakukan digitalisasi pengiriman surat resmi melalui integrasi SMTP/Email client.</span>
          </div>
          <div className="flex items-start gap-2">
            <CheckCircle size={14} className="text-green-500 mt-0.5 flex-shrink-0" />
            <span>Mengarsipkan dan memelihara basis data surat keluar secara digital (Local Storage).</span>
          </div>
        </div>
      </div>
    </div>
  );
}
