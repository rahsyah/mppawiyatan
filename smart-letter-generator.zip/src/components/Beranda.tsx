/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  Sparkles, FileText, BookOpen, Clock, PlayCircle, 
  ChevronRight, Award, Landmark, FileCheck, ShieldAlert 
} from 'lucide-react';

interface BerandaProps {
  onNavigate: (tab: 'generator' | 'panduan' | 'riwayat') => void;
  onSelectChallenge: (type: 'undanganRapat' | 'permohonanPkl') => void;
}

export default function Beranda({ onNavigate, onSelectChallenge }: BerandaProps) {
  
  // Total saved letters count for quick summary representation
  const savedLetters = localStorage.getItem('smart_letter_saved');
  const letterCount = savedLetters ? JSON.parse(savedLetters).length : 0;

  return (
    <div className="space-y-8" id="beranda-root">
      
      {/* 1. Hero Welcoming Section */}
      <div className="relative bg-gradient-to-r from-[#0F4C81] to-blue-900 rounded-3xl p-8 md:p-12 text-white shadow-2xl overflow-hidden border border-white/10">
        {/* Floating gradient circles */}
        <div className="absolute top-[-40px] right-[-40px] w-56 h-56 bg-[#FFC857] opacity-10 rounded-full blur-2xl" />
        <div className="absolute bottom-[-30px] left-[10%] w-44 h-44 bg-blue-400 opacity-20 rounded-full blur-2xl" />

        <div className="relative z-10 grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
          <div className="md:col-span-8 space-y-4 text-center md:text-left">
            <div className="inline-flex items-center gap-1.5 bg-white/10 p-1.5 px-3 rounded-full text-xs font-bold border border-white/20 text-[#FFC857]">
              <Sparkles size={12} className="animate-pulse" />
              Sistem Otomasi Administrasi Perkantoran
            </div>
            
            <h2 className="text-3xl md:text-4xl font-extrabold tracking-tight leading-tight">
              Kuasai Kompetensi Korespondensi Dinas Lebih Cepat!
            </h2>
            
            <p className="text-blue-100 text-sm md:text-base font-light max-w-xl leading-relaxed">
              Selamat datang di simulator <strong>Smart Letter Generator</strong>. Media belajar interaktif modern untuk membantu siswa SMK Manajemen Perkantoran menyusun surat dinas terstandarisasi industri secara instan.
            </p>

            <div className="flex flex-wrap gap-3 pt-2 justify-center md:justify-start">
              <button
                onClick={() => onNavigate('generator')}
                className="bg-[#FFC857] hover:bg-amber-400 text-gray-900 font-extrabold text-xs px-5 py-3 rounded-xl transition-all shadow-md hover:scale-[1.02] flex items-center gap-1.5"
              >
                Mulai Buat Surat
                <PlayCircle size={14} />
              </button>
              
              <button
                onClick={() => onNavigate('panduan')}
                className="bg-white/10 hover:bg-white/15 text-white border border-white/20 font-bold text-xs px-5 py-3 rounded-xl transition-colors flex items-center gap-1.5"
              >
                Pelajari Sistematika
                <BookOpen size={14} />
              </button>
            </div>
          </div>

          <div className="hidden md:flex md:col-span-4 justify-center">
            {/* Visual illustrative computer showing a letter */}
            <div className="w-56 h-56 bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 p-4 shadow-2xl flex flex-col justify-between">
              <div className="flex items-center justify-between border-b border-white/10 pb-2">
                <span className="text-[10px] uppercase font-mono tracking-wider font-extrabold text-[#FFC857]">Pratinjau Simulator</span>
                <div className="flex gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-red-400" />
                  <span className="w-1.5 h-1.5 rounded-full bg-yellow-400" />
                  <span className="w-1.5 h-1.5 rounded-full bg-green-400" />
                </div>
              </div>
              
              {/* Virtual mini letter lines */}
              <div className="space-y-2 py-4 flex-1">
                <div className="h-3 bg-[#FFC857] w-2/3 rounded-full opacity-70" />
                <div className="h-1 bg-white/20 w-full rounded-full" />
                <div className="h-1 bg-white/20 w-5/6 rounded-full" />
                <div className="h-2 bg-white/40 w-1/3 rounded-full mt-2" />
                <div className="h-1 bg-white/20 w-4/5 rounded-full" />
                <div className="h-1 bg-white/20 w-full rounded-full" />
                <div className="h-1 bg-white/20 w-full rounded-full" />
              </div>

              <div className="flex justify-end pt-2 border-t border-white/10 text-[9px] text-white/50">
                A4 PORTRAIT • HD
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Quick statistics cards - Editorial Aesthetic Style */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-5">
        
        <div className="bg-white p-5 rounded-[14px] shadow-sm border border-slate-200 flex items-center gap-4">
          <div className="p-3 bg-[#0F4C81]/10 text-[#0F4C81] rounded-xl">
            <FileText size={20} />
          </div>
          <div>
            <div className="text-[10px] uppercase tracking-wider font-bold text-slate-400">Total Surat Anda</div>
            <div className="text-lg font-bold text-slate-800">{letterCount} File</div>
          </div>
        </div>

        <div className="bg-white p-5 rounded-[14px] shadow-sm border border-slate-200 flex items-center gap-4">
          <div className="p-3 bg-amber-50 text-amber-700 rounded-xl">
            <BookOpen size={20} />
          </div>
          <div>
            <div className="text-[10px] uppercase tracking-wider font-bold text-slate-400">Sistematika Surat</div>
            <div className="text-lg font-bold text-slate-800">9 Komponen</div>
          </div>
        </div>

        <div className="bg-white p-5 rounded-[14px] shadow-sm border border-slate-200 flex items-center gap-4">
          <div className="p-3 bg-green-50 text-green-700 rounded-xl">
            <Award size={20} />
          </div>
          <div>
            <div className="text-[10px] uppercase tracking-wider font-bold text-slate-400">Status Akun</div>
            <div className="text-lg font-bold text-green-600">Siswa Aktif</div>
          </div>
        </div>

        <div className="bg-white p-5 rounded-[14px] shadow-sm border border-slate-200 flex items-center gap-4">
          <div className="p-3 bg-blue-50 text-blue-700 rounded-xl">
            <Clock size={20} />
          </div>
          <div>
            <div className="text-[10px] uppercase tracking-wider font-bold text-slate-400">Waktu Latihan</div>
            <div className="text-lg font-bold text-slate-800">Real-Time</div>
          </div>
        </div>

      </div>

      {/* 3. Daily Challenges / Exercises (Pedagogical Focus) */}
      <div className="bg-white p-6 md:p-8 rounded-[14px] shadow-md border border-slate-200/80 space-y-6">
        <div>
          <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
            <Award className="text-[#FFC857]" size={20} />
            Latihan Mandiri & Tantangan Belajar Hari Ini
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            Pilih tugas di bawah ini untuk memuat struktur surat otomatis di lembar simulator dan mulailah merapikan data korespondensi.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          
          {/* Challenge 1: Undangan Rapat */}
          <div className="border border-slate-200/80 bg-slate-50/50 hover:bg-white p-5 rounded-[14px] transition-all hover:shadow-md flex flex-col justify-between gap-4">
            <div className="space-y-2">
              <span className="bg-blue-100 text-[#0F4C81] text-[9px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider">
                Tingkat: Dasar (Pemula)
              </span>
              <h4 className="font-bold text-slate-800 text-sm leading-tight">
                Tugas 1: Undangan Rapat Organisasi Komite Sekolah
              </h4>
              <p className="text-slate-500 text-xs leading-relaxed">
                Tantangan bagi siswa untuk membuat surat dinas undangan resmi kepada jajaran wali murid kelas XI guna mempersiapkan Praktik Kerja Lapangan (PKL).
              </p>
            </div>
            
            <button
              onClick={() => onSelectChallenge('undanganRapat')}
              className="text-xs font-bold text-[#0F4C81] hover:text-blue-800 flex items-center gap-1 mt-2 self-start"
            >
              Mulai Latihan Sekarang
              <ChevronRight size={14} />
            </button>
          </div>

          {/* Challenge 2: Permohonan PKL */}
          <div className="border border-slate-200/80 bg-slate-50/50 hover:bg-white p-5 rounded-[14px] transition-all hover:shadow-md flex flex-col justify-between gap-4">
            <div className="space-y-2">
              <span className="bg-amber-100 text-amber-800 text-[9px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider">
                Tingkat: Menengah
              </span>
              <h4 className="font-bold text-slate-800 text-sm leading-tight">
                Tugas 2: Surat Permohonan Penempatan Praktik Kerja Lapangan (PKL)
              </h4>
              <p className="text-slate-500 text-xs leading-relaxed">
                Buatlah surat pengajuan kerja sama resmi dari pihak sekolah kepada pimpinan HRD Perusahaan Mitra untuk menempatkan siswa magang.
              </p>
            </div>
            
            <button
              onClick={() => onSelectChallenge('permohonanPkl')}
              className="text-xs font-bold text-amber-700 hover:text-amber-800 flex items-center gap-1 mt-2 self-start"
            >
              Mulai Latihan Sekarang
              <ChevronRight size={14} />
            </button>
          </div>

        </div>
      </div>

      {/* 4. Smart step guidelines */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        
        <div className="bg-white p-5 rounded-[14px] shadow-sm border border-slate-200 space-y-3">
          <div className="w-8 h-8 rounded-full bg-[#0F4C81]/10 text-[#0F4C81] flex items-center justify-center font-bold text-xs font-mono">
            01
          </div>
          <h4 className="font-bold text-slate-800 text-xs">Isi Formulir Surat</h4>
          <p className="text-slate-400 text-[11px] leading-relaxed">
            Ketik nomor surat, tanggal, detail instansi, serta isi surat lengkap Anda di editor sebelah kiri.
          </p>
        </div>

        <div className="bg-white p-5 rounded-[14px] shadow-sm border border-slate-200 space-y-3">
          <div className="w-8 h-8 rounded-full bg-[#FFC857]/20 text-amber-700 flex items-center justify-center font-bold text-xs font-mono">
            02
          </div>
          <h4 className="font-bold text-slate-800 text-xs">Amati Real-time Preview</h4>
          <p className="text-slate-400 text-[11px] leading-relaxed">
            Amati tata letak surat yang langsung ter-update di panel kanan sesuai dengan format resmi administrasi Indonesia.
          </p>
        </div>

        <div className="bg-white p-5 rounded-[14px] shadow-sm border border-slate-200 space-y-3">
          <div className="w-8 h-8 rounded-full bg-green-50 text-green-700 flex items-center justify-center font-bold text-xs font-mono">
            03
          </div>
          <h4 className="font-bold text-slate-800 text-xs">Cetak & Unduh Dokumen</h4>
          <p className="text-slate-400 text-[11px] leading-relaxed">
            Ekspor surat menjadi PDF HD kualitas cetak atau kirim via email langsung untuk diverifikasi oleh guru.
          </p>
        </div>

      </div>

    </div>
  );
}
