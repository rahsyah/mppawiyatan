/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { LetterData } from '../types';

export const TEMPLATE_SURAT: Record<string, Partial<LetterData>> = {
  undanganRapat: {
    nomorSurat: '421.3/SMK-ADM/VII/2026',
    namaInstansi: 'SMK NEGERI 1 JAKARTA\nKOMPETENSI KEAHLIAN MANAJEMEN PERKANTORAN',
    kopSurat: 'Jl. Pemuda No. 10, Rawamangun, Jakarta Timur\nTelp: (021) 4721345 | Email: info@smkn1jakarta.sch.id',
    logoInstansi: '', // We can use a default geometric SVG logo in the UI
    tanggalSurat: '2026-07-06',
    kepada: 'Yth. Bapak/Ibu Orang Tua / Wali Siswa\nKelas XI Manajemen Perkantoran 1\ndi Tempat',
    isiSurat: `
      <p>Dengan hormat,</p>
      <p>Sehubungan dengan akan dilaksanakannya kegiatan <strong>Praktik Kerja Lapangan (PKL)</strong> bagi siswa Kelas XI semester ganjil tahun ajaran 2026/2027, kami mengundang Bapak/Ibu Orang Tua/Wali murid untuk menghadiri rapat koordinasi yang akan dilaksanakan pada:</p>
      <ul>
        <li><strong>Hari/Tanggal:</strong> Senin, 13 Juli 2026</li>
        <li><strong>Waktu:</strong> 09.00 WIB s.d Selesai</li>
        <li><strong>Tempat:</strong> Aula Utama SMK Negeri 1 Jakarta</li>
        <li><strong>Agenda:</strong> Sosialisasi dan Persiapan Pemberangkatan PKL</li>
      </ul>
      <p>Mengingat pentingnya acara ini demi kelancaran pelaksanaan PKL putra/putri Bapak/Ibu, kami sangat mengharapkan kehadiran Bapak/Ibu tepat pada waktunya.</p>
      <p>Demikian surat undangan ini kami sampaikan. Atas perhatian dan kerja sama Bapak/Ibu, kami mengucapkan terima kasih.</p>
    `,
    namaPimpinan: 'Drs. H. Ahmad Sudrajat, M.Pd.',
    jabatan: 'Kepala Sekolah',
    tembusan: '1. Komite Sekolah SMK Negeri 1 Jakarta\n2. Ketua Program Keahlian Manajemen Perkantoran\n3. Arsip Perpustakaan',
  },
  permohonanPkl: {
    nomorSurat: '422.1/SMK-PKL/VI/2026',
    namaInstansi: 'SMK BINA PRESTASI\nPROGRAM KEAHLIAN OTOMATISASI & TATA KELOLA PERKANTORAN',
    kopSurat: 'Jl. Merdeka Belajar No. 45, Kota Bandung\nTelp: (022) 7564839 | Email: humas@smkbinaprestasi.sch.id',
    logoInstansi: '',
    tanggalSurat: '2026-07-04',
    kepada: 'Yth. Ibu Kepala Bagian HRD\nPT Nusantara Jaya Abadi\nJl. Asia Afrika No. 100, Bandung',
    isiSurat: `
      <p>Dengan hormat,</p>
      <p>Dalam rangka menyelaraskan kompetensi siswa Sekolah Menengah Kejuruan (SMK) dengan kebutuhan Dunia Usaha dan Dunia Industri (DUDI), kurikulum SMK mewajibkan pelaksanaan <strong>Praktik Kerja Lapangan (PKL)</strong> selama 3 hingga 6 bulan.</p>
      <p>Oleh karena itu, kami bermaksud mengajukan permohonan kerja sama untuk menempatkan siswa kami melaksanakan PKL di perusahaan yang Ibu pimpin. Adapun rincian pengajuan adalah sebagai berikut:</p>
      <ul>
        <li><strong>Jumlah Siswa:</strong> 2 (Dua) Orang Siswa</li>
        <li><strong>Program Keahlian:</strong> Manajemen Perkantoran & Layanan Bisnis</li>
        <li><strong>Durasi Waktu:</strong> 1 Agustus 2026 s.d. 31 Oktober 2026 (3 Bulan)</li>
      </ul>
      <p>Sebagai bahan pertimbangan, bersama surat ini kami lampirkan proposal PKL beserta daftar riwayat hidup singkat siswa yang bersangkutan.</p>
      <p>Demikian surat permohonan ini kami sampaikan. Besar harapan kami kiranya Ibu dapat menerima putra-putri terbaik kami untuk menimba ilmu di PT Nusantara Jaya Abadi. Atas perhatian Ibu, kami mengucapkan terima kasih.</p>
    `,
    namaPimpinan: 'Ir. Hermawan Pratama, M.B.A.',
    jabatan: 'Kepala Humas & Hubin',
    tembusan: '1. Kepala SMK Bina Prestasi\n2. Koordinator PKL\n3. Arsip',
  },
};

const b64EncodeUnicode = (str: string) => {
  return btoa(
    encodeURIComponent(str).replace(/%([0-9A-F]{2})/g, function (_, p1) {
      return String.fromCharCode(parseInt(p1, 16));
    })
  );
};

const rawLogo = `<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 100 100"><circle cx="50" cy="50" r="45" fill="#0F4C81" opacity="0.1"/><circle cx="50" cy="50" r="35" fill="none" stroke="#0F4C81" stroke-width="3"/><path d="M50 20 L80 40 L80 75 L20 75 L20 40 Z" fill="none" stroke="#0F4C81" stroke-width="3" stroke-linejoin="round"/><path d="M20 40 L50 60 L80 40" fill="none" stroke="#0F4C81" stroke-width="3" stroke-linejoin="round"/><path d="M50 25 L50 45" stroke="#FFC857" stroke-width="3" stroke-linecap="round"/><circle cx="50" cy="48" r="4" fill="#FFC857"/></svg>`;

const rawTtd = `<svg xmlns="http://www.w3.org/2000/svg" width="200" height="80" viewBox="0 0 200 80"><path d="M30 40 C 60 10, 80 60, 100 30 C 120 10, 140 70, 170 40" fill="none" stroke="#0F4C81" stroke-width="3" stroke-linecap="round"/><path d="M25 45 C 50 45, 100 48, 175 42" fill="none" stroke="#FFC857" stroke-width="2" stroke-linecap="round"/><text x="40" y="70" font-family="monospace" font-size="10" fill="#a0aec0" letter-spacing="1">VERIFIED CERTIFICATE</text></svg>`;

export const DEFAULT_LOGO_SVG = `data:image/svg+xml;base64,${b64EncodeUnicode(rawLogo)}`;

export const DEFAULT_TTD_SVG = `data:image/svg+xml;base64,${b64EncodeUnicode(rawTtd)}`;
