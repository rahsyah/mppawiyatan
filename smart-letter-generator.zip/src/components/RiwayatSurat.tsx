/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { SavedLetter } from '../types';
import { FileText, Download, Edit2, Trash2, Search, Filter, RefreshCw, Calendar, Eye, Send } from 'lucide-react';
import Swal from 'sweetalert2';
import { downloadLetterPDF } from '../services/pdfService';

interface RiwayatSuratProps {
  onEdit: (letter: SavedLetter) => void;
  onRefreshTrigger?: number;
}

export default function RiwayatSurat({ onEdit, onRefreshTrigger = 0 }: RiwayatSuratProps) {
  const [letters, setLetters] = useState<SavedLetter[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [loadingId, setLoadingId] = useState<string | null>(null);

  // Load saved letters
  const loadLetters = () => {
    try {
      const stored = localStorage.getItem('smart_letter_saved');
      if (stored) {
        setLetters(JSON.parse(stored));
      } else {
        setLetters([]);
      }
    } catch (e) {
      console.error('Gagal memuat riwayat surat:', e);
    }
  };

  useEffect(() => {
    loadLetters();
  }, [onRefreshTrigger]);

  // Handle Delete with SweetAlert2
  const handleDelete = (id: string, nomor: string) => {
    Swal.fire({
      title: 'Hapus Riwayat Surat?',
      text: `Surat dengan nomor "${nomor}" akan dihapus permanen dari memori lokal browser Anda.`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#d33',
      cancelButtonColor: '#3085d6',
      confirmButtonText: 'Ya, Hapus!',
      cancelButtonText: 'Batal'
    }).then((result) => {
      if (result.isConfirmed) {
        try {
          const stored = localStorage.getItem('smart_letter_saved');
          if (stored) {
            const parsed: SavedLetter[] = JSON.parse(stored);
            const filtered = parsed.filter(l => l.id !== id);
            localStorage.setItem('smart_letter_saved', JSON.stringify(filtered));
            setLetters(filtered);
            Swal.fire({
              title: 'Berhasil!',
              text: 'Surat telah dihapus dari riwayat.',
              icon: 'success',
              timer: 1500,
              showConfirmButton: false
            });
          }
        } catch (e) {
          Swal.fire('Error', 'Gagal menghapus surat', 'error');
        }
      }
    });
  };

  // Handle direct PDF Download
  const handleDownloadPDF = async (letter: SavedLetter) => {
    setLoadingId(letter.id);
    try {
      // Since downloading requires the letter DOM node, we can temporarily load it or create an invisible rendering node
      // Or safer: We can alert the user to click Edit first to load the live preview and then click download.
      // But we can also programmatically mount a temporary invisible container, render the letter preview, capture it, and delete the container!
      // This is a GENIUS implementation! Let's write that.
      
      const tempDiv = document.createElement('div');
      tempDiv.id = 'temp-pdf-render';
      tempDiv.style.position = 'absolute';
      tempDiv.style.left = '-9999px';
      tempDiv.style.top = '-9999px';
      tempDiv.style.width = '794px'; // ~A4 width in px at 96 dpi
      tempDiv.style.backgroundColor = '#ffffff';
      
      // Construct a high-fidelity HTML letter
      tempDiv.innerHTML = `
        <div style="padding: 40px; font-family: 'Times New Roman', Times, serif; color: #000000; line-height: 1.5; font-size: 13px;">
          <!-- Kop Surat -->
          <table style="width: 100%; border-collapse: collapse; margin-bottom: 5px;">
            <tr>
              ${letter.logoInstansi ? `
                <td style="width: 80px; vertical-align: middle; padding-right: 15px;">
                  <img src="${letter.logoInstansi}" style="max-width: 85px; max-height: 85px;" />
                </td>
              ` : ''}
              <td style="text-align: center; vertical-align: middle;">
                <h1 style="font-size: 16px; font-weight: bold; margin: 0; text-transform: uppercase;">${letter.namaInstansi.replace(/\n/g, '<br/>')}</h1>
                <p style="font-size: 10px; margin: 5px 0 0 0; font-style: italic;">${letter.kopSurat.replace(/\n/g, '<br/>')}</p>
              </td>
            </tr>
          </table>
          <div style="border-top: 3px solid #000000; border-bottom: 1px solid #000000; height: 3px; margin: 5px 0 15px 0;"></div>
          
          <!-- Nomor, Tgl, dll -->
          <table style="width: 100%; margin-bottom: 15px;">
            <tr>
              <td style="width: 60%;">
                <strong>Nomor:</strong> ${letter.nomorSurat}<br/>
                <strong>Lampiran:</strong> -<br/>
                <strong>Hal:</strong> Permohonan / Undangan Resmi
              </td>
              <td style="width: 40%; text-align: right; vertical-align: top;">
                ${letter.tanggalSurat ? new Date(letter.tanggalSurat).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' }) : '-'}
              </td>
            </tr>
          </table>

          <!-- Penerima -->
          <div style="margin-bottom: 20px;">
            <p style="margin: 0;"><strong>Kepada Yth.</strong></p>
            <p style="margin: 3px 0 0 0; white-space: pre-line;">${letter.kepada}</p>
          </div>

          <!-- Isi -->
          <div style="margin-bottom: 30px; text-align: justify; line-height: 1.6;">
            ${letter.isiSurat}
          </div>

          <!-- TTD Section -->
          <table style="width: 100%; margin-top: 40px;">
            <tr>
              <td style="width: 60%;"></td>
              <td style="width: 40%; text-align: center;">
                <p style="margin-bottom: 45px;"><strong>${letter.jabatan}</strong>,</p>
                ${letter.gambarTtd ? `
                  <div style="margin: -35px 0 -15px 0;">
                    <img src="${letter.gambarTtd}" style="max-height: 75px; margin: 0 auto;" />
                  </div>
                ` : '<div style="height: 45px;"></div>'}
                <p style="margin: 10px 0 0 0; text-decoration: underline; font-weight: bold;">${letter.namaPimpinan}</p>
              </td>
            </tr>
          </table>

          <!-- Tembusan -->
          ${letter.tembusan ? `
            <div style="margin-top: 30px; font-size: 11px; border-top: 1px dashed #cccccc; pt: 10px;">
              <strong>Tembusan:</strong>
              <p style="margin: 3px 0 0 0; white-space: pre-line; color: #555555;">${letter.tembusan}</p>
            </div>
          ` : ''}
        </div>
      `;

      document.body.appendChild(tempDiv);
      await downloadLetterPDF('temp-pdf-render', letter.nomorSurat);
      document.body.removeChild(tempDiv);
      
      Swal.fire({
        title: 'Sukses!',
        text: 'Surat berhasil dikonversi ke PDF dan diunduh.',
        icon: 'success',
        timer: 1500,
        showConfirmButton: false
      });
    } catch (e: any) {
      console.error(e);
      Swal.fire('Gagal', 'Terjadi kesalahan saat mengunduh PDF: ' + e.message, 'error');
    } finally {
      setLoadingId(null);
    }
  };

  // Filter letters based on search query & status
  const filteredLetters = letters.filter(letter => {
    const matchesSearch = 
      letter.nomorSurat.toLowerCase().includes(searchQuery.toLowerCase()) ||
      letter.namaInstansi.toLowerCase().includes(searchQuery.toLowerCase()) ||
      letter.kepada.toLowerCase().includes(searchQuery.toLowerCase()) ||
      letter.namaPimpinan.toLowerCase().includes(searchQuery.toLowerCase());
      
    const matchesStatus = statusFilter === 'all' || letter.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="bg-white p-6 md:p-8 rounded-[14px] shadow-lg border border-slate-200/80 space-y-6" id="riwayat-surat-root">
      {/* Header and Counters */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-200 pb-5">
        <div>
          <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2">
            <FileText className="text-[#0F4C81]" />
            Riwayat Surat Keluar
          </h3>
          <p className="text-xs text-slate-500 mt-1">
            Data surat yang Anda buat tersimpan aman di penyimpanan lokal web browser Anda.
          </p>
        </div>
        
        {/* Statistics Widgets */}
        <div className="flex gap-4">
          <div className="bg-[#0F4C81]/5 px-4 py-2 rounded-[14px] text-center border border-[#0F4C81]/10">
            <div className="text-xs text-slate-500">Total Surat</div>
            <div className="text-lg font-extrabold text-[#0F4C81]">{letters.length}</div>
          </div>
          <div className="bg-green-50 px-4 py-2 rounded-[14px] text-center border border-green-100">
            <div className="text-xs text-slate-500">Selesai</div>
            <div className="text-lg font-extrabold text-green-600">
              {letters.filter(l => l.status === 'Selesai' || l.status === 'Terkirim').length}
            </div>
          </div>
        </div>
      </div>

      {/* Search and Filters Controls */}
      <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
        <div className="relative w-full md:w-80">
          <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-slate-400">
            <Search size={16} />
          </span>
          <input
            type="text"
            placeholder="Cari nomor, instansi, pimpinan..."
            className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-[14px] text-xs focus:ring-2 focus:ring-[#0F4C81] focus:border-transparent bg-slate-50 focus:bg-white transition-all outline-none"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <div className="flex gap-2 w-full md:w-auto justify-end">
          <div className="flex items-center gap-1.5 border border-slate-200 px-3 py-1.5 rounded-[14px] bg-slate-50 text-xs text-slate-600">
            <Filter size={14} />
            <span>Filter Status:</span>
            <select
              className="bg-transparent border-none outline-none font-semibold text-[#0F4C81] cursor-pointer"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <option value="all">Semua Status</option>
              <option value="Draft">Draft</option>
              <option value="Terkirim">Terkirim</option>
              <option value="Selesai">Selesai</option>
            </select>
          </div>

          <button
            onClick={loadLetters}
            className="p-2 border border-slate-200 rounded-[14px] bg-slate-50 hover:bg-slate-100 text-slate-600 transition-all hover:rotate-45"
            title="Muat Ulang Riwayat"
          >
            <RefreshCw size={15} />
          </button>
        </div>
      </div>

      {/* Letters Table / Grid */}
      {filteredLetters.length === 0 ? (
        <div className="text-center py-16 border-2 border-dashed border-slate-200 rounded-[14px] bg-slate-50/50 space-y-3">
          <div className="w-12 h-12 bg-slate-100 text-slate-400 rounded-full flex items-center justify-center mx-auto">
            <FileText size={24} />
          </div>
          <div className="space-y-1">
            <h4 className="font-bold text-slate-700 text-sm">Tidak Ada Surat Ditemukan</h4>
            <p className="text-xs text-slate-400 max-w-xs mx-auto">
              Belum ada arsip surat atau tidak ada yang sesuai dengan pencarian Anda saat ini.
            </p>
          </div>
        </div>
      ) : (
        <div className="overflow-x-auto rounded-[14px] border border-slate-200 shadow-sm">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-50 text-gray-600 text-xs font-bold border-b border-gray-100">
                <th className="p-4">Nomor Surat / Instansi</th>
                <th className="p-4">Tanggal</th>
                <th className="p-4">Penerima (Kepada)</th>
                <th className="p-4 text-center">Status</th>
                <th className="p-4 text-center">Aksi Kerja</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50 text-xs text-gray-700">
              {filteredLetters.map((letter) => (
                <tr key={letter.id} className="hover:bg-gray-50/70 transition-colors">
                  <td className="p-4 space-y-1 max-w-[250px]">
                    <div className="font-bold text-gray-800 break-all">{letter.nomorSurat || '(Belum diatur)'}</div>
                    <div className="text-[10px] text-[#0F4C81] line-clamp-1">{letter.namaInstansi.split('\n')[0]}</div>
                  </td>
                  <td className="p-4">
                    <div className="flex items-center gap-1.5 text-gray-600">
                      <Calendar size={13} className="text-gray-400" />
                      <span>
                        {letter.tanggalSurat
                          ? new Date(letter.tanggalSurat).toLocaleDateString('id-ID', {
                              day: 'numeric',
                              month: 'short',
                              year: 'numeric',
                            })
                          : '-'}
                      </span>
                    </div>
                  </td>
                  <td className="p-4">
                    <div className="line-clamp-2 text-gray-600 max-w-[200px]" title={letter.kepada}>
                      {letter.kepada}
                    </div>
                  </td>
                  <td className="p-4 text-center">
                    <span
                      className={`inline-block px-2.5 py-1 rounded-full text-[10px] font-bold ${
                        letter.status === 'Selesai'
                          ? 'bg-blue-50 text-[#0F4C81] border border-blue-200'
                          : letter.status === 'Terkirim'
                          ? 'bg-green-50 text-green-700 border border-green-200'
                          : 'bg-amber-50 text-amber-700 border border-amber-200'
                      }`}
                    >
                      {letter.status}
                    </span>
                  </td>
                  <td className="p-4">
                    <div className="flex justify-center items-center gap-1.5">
                      {/* Edit Button */}
                      <button
                        onClick={() => onEdit(letter)}
                        className="p-1.5 bg-blue-50 text-[#0F4C81] hover:bg-[#0F4C81] hover:text-white rounded-lg transition-all"
                        title="Edit / Modifikasi Surat"
                      >
                        <Edit2 size={13} />
                      </button>

                      {/* Download PDF Button */}
                      <button
                        disabled={loadingId === letter.id}
                        onClick={() => handleDownloadPDF(letter)}
                        className={`p-1.5 bg-green-50 text-green-700 hover:bg-green-600 hover:text-white rounded-lg transition-all ${
                          loadingId === letter.id ? 'opacity-50 cursor-wait' : ''
                        }`}
                        title="Unduh sebagai PDF HD"
                      >
                        <Download size={13} />
                      </button>

                      {/* Delete Button */}
                      <button
                        onClick={() => handleDelete(letter.id, letter.nomorSurat)}
                        className="p-1.5 bg-red-50 text-red-600 hover:bg-red-600 hover:text-white rounded-lg transition-all"
                        title="Hapus Permanen"
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
