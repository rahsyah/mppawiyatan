/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Home, FileEdit, History, BookOpen, Info, HelpCircle, 
  GraduationCap, Sparkles, AlertCircle, CheckCircle, Smartphone, 
  Map, Moon, Sun, ArrowRight, Book 
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import Beranda from './components/Beranda';
import Generator from './components/Generator';
import RiwayatSurat from './components/RiwayatSurat';
import PanduanBelajar from './components/PanduanBelajar';
import TentangAplikasi from './components/TentangAplikasi';
import { SavedLetter } from './types';
import { TEMPLATE_SURAT, DEFAULT_LOGO_SVG, DEFAULT_TTD_SVG } from './utils/defaultData';
import Swal from 'sweetalert2';

type ActiveTab = 'beranda' | 'generator' | 'riwayat' | 'panduan' | 'tentang';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('beranda');
  
  // To handle edit actions from RiwayatSurat to Generator
  const [selectedLetterToEdit, setSelectedLetterToEdit] = useState<SavedLetter | null>(null);
  
  // Keep track of refresh events to trigger child component updates
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  // Quick help sidebar / floating card state
  const [isHelpOpen, setIsHelpOpen] = useState(false);

  // Theme support
  const [darkMode, setDarkMode] = useState(false);

  // Handle Edit Letter clicked in RiwayatSurat
  const handleEditLetter = (letter: SavedLetter) => {
    setSelectedLetterToEdit(letter);
    setActiveTab('generator');
  };

  // Trigger child list refresh
  const triggerRefresh = () => {
    setRefreshTrigger(prev => prev + 1);
  };

  // Handle Challenge Click on Homepage
  const handleSelectChallenge = (type: 'undanganRapat' | 'permohonanPkl') => {
    const base = TEMPLATE_SURAT[type];
    const challengeLetter: SavedLetter = {
      id: 'challenge_' + Date.now(),
      nomorSurat: base.nomorSurat || '',
      namaInstansi: base.namaInstansi || '',
      kopSurat: base.kopSurat || '',
      logoInstansi: DEFAULT_LOGO_SVG,
      tanggalSurat: base.tanggalSurat || new Date().toISOString().split('T')[0],
      kepada: base.kepada || '',
      isiSurat: base.isiSurat || '',
      gambarTtd: DEFAULT_TTD_SVG,
      namaPimpinan: base.namaPimpinan || '',
      jabatan: base.jabatan || '',
      tembusan: base.tembusan || '',
      createdAt: new Date().toISOString(),
      status: 'Draft',
    };
    
    setSelectedLetterToEdit(challengeLetter);
    setActiveTab('generator');
    
    // Smooth scroll to top of generator
    window.scrollTo({ top: 0, behavior: 'smooth' });
    
    Swal.fire({
      title: 'Tugas Belajar Dimuat!',
      text: 'Struktur draf template latihan berhasil di-import ke simulator.',
      icon: 'success',
      timer: 1500,
      showConfirmButton: false
    });
  };

  return (
    <div className={`min-h-screen font-sans transition-colors duration-300 ${
      darkMode ? 'bg-slate-950 text-white' : 'bg-[#F8FAFC] text-slate-800'
    }`}>
      
      {/* BACKGROUND GRAPHIC OR OFFICE GRADIENT */}
      <div className="absolute top-0 inset-x-0 h-[380px] bg-gradient-to-b from-[#0F4C81]/10 via-blue-50/0 to-transparent pointer-events-none -z-10" />

      {/* GLOBAL HEADER BAR - Editorial Aesthetic Theme */}
      <header className="sticky top-0 z-40 bg-[#0F4C81] text-white shadow-lg z-10 transition-colors">
        <div className="max-w-7xl mx-auto px-4 md:px-6 py-4 flex flex-col md:flex-row justify-between items-center gap-4">
          
          {/* Logo and App Title */}
          <div className="flex items-center gap-4 text-center md:text-left">
            <div className="w-11 h-11 bg-[#FFC857] rounded-lg flex items-center justify-center text-[#0F4C81] shadow-inner shrink-0">
              <GraduationCap size={24} className="animate-pulse" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight leading-none text-white flex items-center gap-1.5 justify-center md:justify-start">
                SMART LETTER GENERATOR
              </h1>
              <p className="text-[10px] uppercase tracking-widest text-blue-100/70 mt-1">
                Media Pembelajaran Surat Menyurat Digital SMK
              </p>
            </div>
          </div>

          {/* Quick global controls (Theme & Help) */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setDarkMode(!darkMode)}
              className="p-2 hover:bg-white/10 text-white rounded-xl transition-colors"
              title={darkMode ? 'Aktifkan Mode Terang' : 'Aktifkan Mode Gelap'}
            >
              {darkMode ? <Sun size={18} /> : <Moon size={18} />}
            </button>

            <button
              onClick={() => setIsHelpOpen(!isHelpOpen)}
              className="p-2 hover:bg-white/10 text-white rounded-xl transition-colors flex items-center gap-1.5 text-xs font-semibold"
              title="Panduan Pintar & Shortcut"
            >
              <HelpCircle size={18} />
              <span className="hidden sm:inline">Bantuan</span>
            </button>
            
            <span className="hidden md:inline bg-[#FFC857] text-[#0F4C81] text-[10px] font-bold px-3 py-1.5 rounded-lg">
              Vokasi Hebat • SMK Kuat
            </span>
          </div>

        </div>

        {/* NAVIGATION TAB BAR */}
        <div className="border-t border-white/10 bg-white/5">
          <div className="max-w-7xl mx-auto px-4 md:px-6">
            <nav className="flex overflow-x-auto gap-1 md:gap-2 py-2.5 no-scrollbar" aria-label="Menu Utama">
              {[
                { id: 'beranda', label: 'Beranda', icon: Home },
                { id: 'generator', label: 'Generator', icon: FileEdit },
                { id: 'riwayat', label: 'Riwayat', icon: History },
                { id: 'panduan', label: 'Panduan', icon: BookOpen },
                { id: 'tentang', label: 'Tentang', icon: Info },
              ].map((tab) => {
                const IconComponent = tab.icon;
                const isActive = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => {
                      if (tab.id !== 'generator') {
                        setSelectedLetterToEdit(null); // Reset passing edit state
                      }
                      setActiveTab(tab.id as ActiveTab);
                    }}
                    className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-all shrink-0 select-none border ${
                      isActive
                        ? 'bg-[#FFC857] text-[#0F4C81] border-[#FFC857] font-bold shadow-md'
                        : 'text-white/80 border-transparent hover:bg-white/10 hover:text-white'
                    }`}
                  >
                    <IconComponent size={14} />
                    {tab.label}
                  </button>
                );
              })}
            </nav>
          </div>
        </div>
      </header>

      {/* CORE BODY WRAPPER */}
      <main className="max-w-7xl mx-auto px-4 md:px-6 py-8 md:py-10">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.25 }}
          >
            {activeTab === 'beranda' && (
              <Beranda 
                onNavigate={(target) => setActiveTab(target)} 
                onSelectChallenge={handleSelectChallenge}
              />
            )}
            
            {activeTab === 'generator' && (
              <Generator 
                initialLetterData={selectedLetterToEdit} 
                onSavedTrigger={triggerRefresh}
              />
            )}
            
            {activeTab === 'riwayat' && (
              <RiwayatSurat 
                onEdit={handleEditLetter} 
                onRefreshTrigger={refreshTrigger}
              />
            )}
            
            {activeTab === 'panduan' && (
              <PanduanBelajar />
            )}
            
            {activeTab === 'tentang' && (
              <TentangAplikasi />
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* FOOTER BAR */}
      <footer className="bg-white dark:bg-slate-900 border-t border-gray-100 dark:border-slate-800 py-8 text-center text-xs text-gray-400 dark:text-gray-500 mt-20 transition-colors">
        <div className="max-w-7xl mx-auto px-4 space-y-2">
          <p className="font-semibold text-gray-500 dark:text-gray-400">
            Smart Letter Generator v1.0 • Media Pembelajaran SMK Korespondensi Administrasi Perkantoran
          </p>
          <p>
            Mendukung peningkatan mutu literasi dan keterampilan administrasi digital siswa Indonesia.
          </p>
          <p className="text-[10px] text-gray-300 dark:text-gray-600 pt-2 font-mono">
            Platform Pembelajaran Mandiri • Bebas Hak Cipta Untuk Tujuan Pendidikan Vokasi
          </p>
        </div>
      </footer>

      {/* FLOATING ACTION HELP DRAWER / MODAL POPUP */}
      <AnimatePresence>
        {isHelpOpen && (
          <div className="fixed inset-0 bg-black/55 backdrop-blur-xs z-50 flex justify-end">
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="w-full max-w-md bg-white dark:bg-slate-900 h-full p-6 md:p-8 shadow-2xl flex flex-col justify-between overflow-y-auto border-l border-gray-150 dark:border-slate-800"
            >
              <div className="space-y-6">
                
                {/* Help Header */}
                <div className="flex justify-between items-center border-b border-gray-100 dark:border-slate-800 pb-4">
                  <h4 className="font-extrabold text-[#0F4C81] dark:text-blue-400 text-sm flex items-center gap-2">
                    <HelpCircle size={18} />
                    Pusat Bantuan & Tanya Jawab Siswa
                  </h4>
                  <button
                    onClick={() => setIsHelpOpen(false)}
                    className="p-1 text-gray-400 hover:text-gray-600 font-bold"
                  >
                    ✕
                  </button>
                </div>

                {/* FAQ Block */}
                <div className="space-y-4 text-xs leading-relaxed text-gray-600 dark:text-gray-300">
                  
                  <div className="space-y-1">
                    <h5 className="font-bold text-gray-800 dark:text-white">❓ Bagaimana cara menyimpan surat saya?</h5>
                    <p>Setelah Anda melengkapi semua isian form, klik tombol <strong>"Generate Surat"</strong> di bagian bawah form. Surat Anda akan tersimpan otomatis di dalam database lokal browser (Riwayat Surat).</p>
                  </div>

                  <div className="space-y-1">
                    <h5 className="font-bold text-gray-800 dark:text-white">❓ Mengapa gambar / logo saya tidak muncul?</h5>
                    <p>Pastikan file gambar yang Anda unggah bertipe file standar gambar (PNG, JPG, atau SVG) dan ukuran file tidak melebihi 2MB agar rendering berjalan lancar dan optimal.</p>
                  </div>

                  <div className="space-y-1">
                    <h5 className="font-bold text-gray-800 dark:text-white">❓ Cara mengirim email surat dinas ke Guru?</h5>
                    <p>Gunakan tombol <strong>"Kirim Email"</strong> di atas panel live preview. Pastikan Anda sudah mengonfigurasi kredensial kunci EmailJS Anda pada panel setelan (ikon roda gigi) agar dapat terhubung dengan server pengiriman.</p>
                  </div>

                  <div className="space-y-1">
                    <h5 className="font-bold text-gray-800 dark:text-white">❓ Apakah data surat saya bisa hilang?</h5>
                    <p>Surat Anda disimpan secara mandiri menggunakan fitur LocalStorage browser Anda. Data tidak akan hilang kecuali Anda membersihkan data cache browser atau menggunakan tab penyamaran (Incognito Mode).</p>
                  </div>

                </div>

              </div>

              {/* Bottom Quick Action */}
              <div className="pt-6 border-t border-gray-100 dark:border-slate-800 text-center">
                <button
                  onClick={() => {
                    setIsHelpOpen(false);
                    setActiveTab('panduan');
                  }}
                  className="w-full bg-[#0F4C81] hover:bg-[#0C3C66] text-white text-xs font-bold py-2.5 rounded-xl transition-all shadow-sm flex items-center justify-center gap-1.5"
                >
                  Buka Modul Pembelajaran Lengkap
                  <ArrowRight size={14} />
                </button>
              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
