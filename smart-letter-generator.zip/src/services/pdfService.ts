/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';

interface SanitizedStyle {
  element: HTMLStyleElement | HTMLLinkElement;
  originalText?: string;
  originalDisabled: boolean;
  tempStyleElement?: HTMLStyleElement;
}

/**
 * Helper to temporarily sanitize any oklch color declarations from document stylesheets.
 * Since html2canvas parses style rules and fails on the unsupported oklch color function,
 * we temporarily replace them with fallback rgb colors based on their lightness.
 */
async function runWithSanitizedOklch<T>(action: () => Promise<T>): Promise<T> {
  const sanitized: SanitizedStyle[] = [];
  
  // Helper to convert oklch to rgb
  const replaceOklch = (text: string): string => {
    return text.replace(/oklch\s*\(\s*([0-9.]+)([^)]+)\)/g, (match, lStr) => {
      const L = parseFloat(lStr);
      if (isNaN(L)) return 'rgb(120, 120, 120)';
      const val = Math.round(L * 255);
      return `rgb(${val}, ${val}, ${val})`;
    });
  };

  try {
    // 1. Process all <style> tags
    const styles = Array.from(document.querySelectorAll('style'));
    for (const style of styles) {
      const originalText = style.textContent || '';
      if (originalText.includes('oklch')) {
        sanitized.push({
          element: style,
          originalText,
          originalDisabled: style.disabled
        });
        style.textContent = replaceOklch(originalText);
      }
    }

    // 2. Process all <link rel="stylesheet"> tags
    const links = Array.from(document.querySelectorAll('link[rel="stylesheet"]')) as HTMLLinkElement[];
    for (const link of links) {
      try {
        const sheet = link.sheet;
        if (sheet) {
          let hasOklch = false;
          try {
            const rules = sheet.cssRules;
            for (let i = 0; i < rules.length; i++) {
              if (rules[i].cssText.includes('oklch')) {
                hasOklch = true;
                break;
              }
            }
          } catch (e) {
            // Cross-origin restriction - assume it might have oklch to be safe
            hasOklch = true;
          }

          if (hasOklch) {
            sanitized.push({
              element: link,
              originalDisabled: link.disabled
            });
            link.disabled = true;

            try {
              const response = await fetch(link.href);
              const cssText = await response.text();
              const tempStyle = document.createElement('style');
              tempStyle.textContent = replaceOklch(cssText);
              document.head.appendChild(tempStyle);
              
              sanitized[sanitized.length - 1].tempStyleElement = tempStyle;
            } catch (e) {
              console.warn('Could not fetch external stylesheet for sanitization:', link.href, e);
            }
          }
        }
      } catch (err) {
        console.error('Error processing link element:', link, err);
      }
    }

    // Run the actual canvas capture
    return await action();

  } finally {
    // Restore all original styles
    for (const item of sanitized) {
      if (item.element.tagName === 'STYLE') {
        if (item.originalText !== undefined) {
          item.element.textContent = item.originalText;
        }
      } else if (item.element.tagName === 'LINK') {
        (item.element as HTMLLinkElement).disabled = item.originalDisabled;
      }
      if (item.tempStyleElement) {
        item.tempStyleElement.remove();
      }
    }
  }
}

/**
 * Generates an HD PDF from a DOM element using html2canvas and jsPDF.
 * Automatically saves the PDF and returns a Blob for further actions (e.g., email sending).
 */
export async function downloadLetterPDF(elementId: string, nomorSurat: string): Promise<Blob> {
  const element = document.getElementById(elementId);
  if (!element) {
    throw new Error('Elemen pratinjau surat tidak ditemukan.');
  }

  // Temporarily reset transform & transition styles to prevent cropped or scaled PDF
  const originalTransform = element.style.transform;
  const originalTransition = element.style.transition;
  
  element.style.transform = 'none';
  element.style.transition = 'none';

  // Allow browser layout engine to repaint at 100% scale before html2canvas captures
  await new Promise((resolve) => setTimeout(resolve, 150));

  try {
    // Create a clean canvas representation with high scale for high resolution, wrapped in oklch sanitizer
    const canvas = await runWithSanitizedOklch(async () => {
      return await html2canvas(element, {
        scale: 2, // HD Quality
        useCORS: true,
        logging: false,
        backgroundColor: '#ffffff',
        windowWidth: 794,  // Standard A4 width in px
        windowHeight: 1123, // Standard A4 height in px
      });
    });

    const imgData = canvas.toDataURL('image/jpeg', 0.95);
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
    });

    const imgWidth = 210; // A4 size width in mm
    const pageHeight = 297; // A4 size height in mm
    const imgHeight = (canvas.height * imgWidth) / canvas.width;
    
    let heightLeft = imgHeight;
    let position = 0;

    // Add the first page
    pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight);
    heightLeft -= pageHeight;

    // Handle multi-page PDFs if the content overflows A4 height
    while (heightLeft >= 0) {
      position = heightLeft - imgHeight;
      pdf.addPage();
      pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;
    }

    // Safe file name for the file system
    const safeNomor = nomorSurat.replace(/[\/\\?%*:|"<>\s]/g, '_') || 'Draft';
    const filename = `Surat_${safeNomor}.pdf`;

    pdf.save(filename);

    // Return as Blob for email integration
    return pdf.output('blob');
  } catch (error: any) {
    console.error('Error generating PDF:', error);
    throw new Error(error.message || 'Gagal merender dokumen surat.');
  } finally {
    // Restore original styles
    element.style.transform = originalTransform;
    element.style.transition = originalTransition;
  }
}

/**
 * Helper to convert PDF to Base64 (for potential attachment integrations)
 */
export async function getPDFBase64(elementId: string): Promise<string> {
  const element = document.getElementById(elementId);
  if (!element) return '';
  
  // Temporarily reset transform & transition styles to prevent cropped or scaled PDF
  const originalTransform = element.style.transform;
  const originalTransition = element.style.transition;
  
  element.style.transform = 'none';
  element.style.transition = 'none';

  // Allow browser layout engine to repaint at 100% scale before html2canvas captures
  await new Promise((resolve) => setTimeout(resolve, 150));

  try {
    const canvas = await runWithSanitizedOklch(async () => {
      return await html2canvas(element, {
        scale: 1.5,
        useCORS: true,
        logging: false,
        backgroundColor: '#ffffff',
        windowWidth: 794,
        windowHeight: 1123,
      });
    });
    
    const imgData = canvas.toDataURL('image/jpeg', 0.9);
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });
    
    const imgWidth = 210;
    const imgHeight = (canvas.height * imgWidth) / canvas.width;
    pdf.addImage(imgData, 'JPEG', 0, 0, imgWidth, imgHeight);
    
    return pdf.output('datauristring');
  } finally {
    element.style.transform = originalTransform;
    element.style.transition = originalTransition;
  }
}
